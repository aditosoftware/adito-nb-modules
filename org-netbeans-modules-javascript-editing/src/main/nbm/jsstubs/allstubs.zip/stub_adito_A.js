eMath = {

/**
 * @type Number 
 */
ROUND_CEILING: undefined,

/**
 * @type Number 
 */
ROUND_DOWN: undefined,

/**
 * @type Number 
 */
ROUND_FLOOR: undefined,

/**
 * @type Number 
 */
ROUND_HALF_DOWN: undefined,

/**
 * @type Number 
 */
ROUND_HALF_EVEN: undefined,

/**
 * @type Number 
 */
ROUND_HALF_UP: undefined,

/**
 * @type Number 
 */
ROUND_UP: undefined,

/**
 * @param {String} pB
 * @param {String} pA
 * @type Number
 */
addInt: function(pB, pA){},

/**
 * @param {String} pB
 * @param {String} pA
 * @type Number
 */
addDec: function(pB, pA){},

/**
 * @param {String} pB
 * @param {String} pA
 * @type Number
 */
subInt: function(pB, pA){},

/**
 * @param {String} pB
 * @param {String} pA
 * @type Number
 */
subDec: function(pB, pA){},

/**
 * @param {String} pB
 * @param {String} pA
 * @type Number
 */
mulInt: function(pB, pA){},

/**
 * @param {String} pB
 * @param {String} pA
 * @type Number
 */
mulDec: function(pB, pA){},

/**
 * @param {String} pB
 * @param {String} pA
 * @type Number
 */
divInt: function(pB, pA){},

/**
 * @param {String} pB
 * @param {String} pA
 * @type Number
 */
divDec: function(pB, pA){},

/**
 * @param {Number} pRoundingMode
 * @param {String} pA
 * @type Number
 */
roundInt: function(pRoundingMode, pA){},

/**
 * @param {Number} pRoundingMode
 * @param {Number} pScale
 * @param {String} pA
 * @type Number
 */
roundDec: function(pRoundingMode, pScale, pA){},

/**
 * @param {String} pA
 * @type Number
 */
absInt: function(pA){},

/**
 * @param {String} pA
 * @type Number
 */
absDec: function(pA){},

/**
 * @type String
 */
getReadableID: function(){}

};


SQLTYPES = {

/**
 * @param {Number} pType
 * @type Boolean
 */
isLOBType: function(pType){},

/**
 * @param {Number} pType
 * @type Boolean
 */
isTextType: function(pType){},

/**
 * @param {Number} pType
 * @type Boolean
 */
isNumberType: function(pType){},

/**
 * @param {Number} pType
 * @type Boolean
 */
isDateType: function(pType){}

};


SYSTEM = {

/**
 * @type Number 
 */
EXITCODE_OK: undefined,

/**
 * @type Number 
 */
EXITCODE_ERROR: undefined,

/**
 * @type Number 
 */
EXITCODE_TIMEOUT: undefined,

/**
 * @type Number 
 */
EXITCODE_AUTHFAILED: undefined,

/**
 * @type Number 
 */
EXITCODE_MANAGER: undefined,

/**
 * @type Number 
 */
EXITCODE_EXTERN: undefined,

/**
 * @param {Object} pException
 * @type void
 */
showAndLog: function(pException){},

/**
 * @param {Throwable} pException
 * @param {Object} pDetails
 * @param {Number} pErrorID
 * @param {Boolean} pShowDialog
 * @type void
 */
debug: function(pException, pDetails, pErrorID, pShowDialog){},

/**
 * @param {String} pJarURL
 * @param {String} pClassName
 * @param {Array} pArguments
 * @type Array
 * @throws AditoJDitoException
 */
runPlugin: function(pJarURL, pClassName, pArguments){},

/**
 * @type String
 */
getReadableID: function(){}

};


telephony = {

/**
 * @type String 
 */
CALLID: undefined,

/**
 * @type String 
 */
ADDRESS: undefined,

/**
 * @type String 
 */
ISINCOMING: undefined,

/**
 * @type String 
 */
STATE: undefined,

/**
 * @type String 
 */
LOCALADDRESS: undefined,

/**
 * @type String 
 */
LOCALID: undefined,

/**
 * @type Array
 * @throws AditoJDitoException
 */
getCurrentCalls: function(){},

/**
 * @type Number
 * @throws AditoJDitoException
 */
getCurrentCallCount: function(){},

/**
 * @param {String} pName
 * @type void
 * @throws AditoJDitoException
 */
setCallStartProcess: function(pName){},

/**
 * @param {String} pName
 * @type void
 * @throws AditoJDitoException
 */
setCallEndProcess: function(pName){},

/**
 * @param {String} pName
 * @type void
 * @throws AditoJDitoException
 */
setCallStateChangedProcess: function(pName){},

/**
 * @param {String} pName
 * @type void
 * @throws AditoJDitoException
 */
setPrivateDataCallbackProcess: function(pName){},

/**
 * @param {String} pAddress
 * @type void
 * @throws AditoJDitoException
 */
call: function(pAddress){},

/**
 * @param {String} pPhoneAddress
 * @param {String} pAddress
 * @type void
 * @throws AditoJDitoException
 */
call: function(pPhoneAddress, pAddress){},

/**
 * @param {String} pJDitoCallID
 * @type void
 * @throws AditoJDitoException
 */
switchHold: function(pJDitoCallID){},

/**
 * @param {String} pJDitoCallID
 * @param {String} pAddress
 * @type void
 * @throws AditoJDitoException
 */
joinSetup: function(pJDitoCallID, pAddress){},

/**
 * @param {String} pSecondJDitoCallID
 * @param {String} pFirstJDitoCallID
 * @type void
 * @throws AditoJDitoException
 */
joinFinish: function(pSecondJDitoCallID, pFirstJDitoCallID){},

/**
 * @param {String} pSecondJDitoCallID
 * @param {String} pFirstJDitoCallID
 * @type void
 * @throws AditoJDitoException
 */
join: function(pSecondJDitoCallID, pFirstJDitoCallID){},

/**
 * @param {String} pJDitoCallID
 * @type void
 * @throws AditoJDitoException
 */
answer: function(pJDitoCallID){},

/**
 * @param {String} pJDitoCallID
 * @type void
 * @throws AditoJDitoException
 */
hangup: function(pJDitoCallID){},

/**
 * @param {String} pNewAddress
 * @param {String} pJDitoCallID
 * @type void
 * @throws AditoJDitoException
 */
transferSetup: function(pNewAddress, pJDitoCallID){},

/**
 * @param {String} pSecondJDitoCallID
 * @param {String} pFirstJDitoCallID
 * @type void
 * @throws AditoJDitoException
 */
transferFinish: function(pSecondJDitoCallID, pFirstJDitoCallID){},

/**
 * @param {String} pNewAddress
 * @param {String} pJDitoCallID
 * @type void
 * @throws AditoJDitoException
 */
forward: function(pNewAddress, pJDitoCallID){},

/**
 * @param {String} pNewAddress
 * @param {String} pJDitoCallID
 * @type void
 * @throws AditoJDitoException
 */
transfer: function(pNewAddress, pJDitoCallID){},

/**
 * @param {String} pJDitoCallID
 * @param {Array} pData
 * @type void
 * @throws AditoJDitoException
 */
sendPrivateData: function(pJDitoCallID, pData){},

/**
 * @param {String} pPhoneAddress
 * @param {Array} pData
 * @type void
 * @throws AditoJDitoException
 */
sendStaticPrivateData: function(pPhoneAddress, pData){},

/**
 * @param {String} pProvider
 * @type Array
 * @throws AditoJDitoException
 */
getAvailableAddresses: function(pProvider){},

/**
 * @type Array
 * @throws AditoJDitoException
 */
getAvailablePhoneAddresses: function(){},

/**
 * @param {String} pImageID
 * @param {String} pWindowID
 * @type void
 * @throws AditoJDitoException
 */
addRefreshable: function(pImageID, pWindowID){},

/**
 * @param {String} pImageID
 * @param {String} pWindowID
 * @type void
 * @throws AditoJDitoException
 */
removeRefreshable: function(pImageID, pWindowID){},

/**
 * @type String
 */
getReadableID: function(){}

};


fileIO = {

/**
 * @param {String} pFile
 * @type Boolean
 * @throws AditoJDitoException
 */
canRead: function(pFile){},

/**
 * @param {String} pFile
 * @type Boolean
 * @throws AditoJDitoException
 */
canWrite: function(pFile){},

/**
 * @param {String} pFile
 * @type Boolean
 * @throws AditoJDitoException
 */
remove: function(pFile){},

/**
 * @param {String} pFile
 * @type Boolean
 * @throws AditoJDitoException
 */
exists: function(pFile){},

/**
 * @param {String} pFile
 * @type Boolean
 * @throws AditoJDitoException
 */
isDirectory: function(pFile){},

/**
 * @param {String} pFile
 * @type Boolean
 * @throws AditoJDitoException
 */
isFile: function(pFile){},

/**
 * @param {String} pFile
 * @type Boolean
 * @throws AditoJDitoException
 */
isHidden: function(pFile){},

/**
 * @param {String} pFile
 * @type Number
 * @throws AditoJDitoException
 */
lastModified: function(pFile){},

/**
 * @param {String} pFile
 * @type Number
 * @throws AditoJDitoException
 */
getLength: function(pFile){},

/**
 * @param {String} pFile
 * @param {Boolean} pCreateNonExistant
 * @type Boolean
 * @throws AditoJDitoException
 */
mkdir: function(pFile, pCreateNonExistant){},

/**
 * @param {String} pFile
 * @param {String} pNewFile
 * @type Boolean
 * @throws AditoJDitoException
 */
rename: function(pFile, pNewFile){},

/**
 * @param {String} pFile
 * @type Boolean
 * @throws AditoJDitoException
 */
setReadOnly: function(pFile){},

/**
 * @param {String} pFile
 * @type String
 * @throws AditoJDitoException
 */
getParent: function(pFile){},

/**
 * @param {String} pFile
 * @type String
 * @throws AditoJDitoException
 */
getName: function(pFile){},

/**
 * @param {String} pFile
 * @type String
 * @throws AditoJDitoException
 */
getAbsolute: function(pFile){},

/**
 * @param {String} pFile
 * @type Array
 * @throws AditoJDitoException
 */
listFiles: function(pFile){},

/**
 * @param {String} pFileName
 * @param {Number} pDataType
 * @param {Object} pData
 * @param {Boolean} pAppend
 * @type void
 * @throws AditoJDitoException
 */
storeData: function(pFileName, pDataType, pData, pAppend){},

/**
 * @param {String} pFileName
 * @param {Number} pDataType
 * @type String
 * @throws AditoJDitoException
 */
getData: function(pFileName, pDataType){},

/**
 * @param {String} pFile
 * @param {String} pFilter
 * @type Array
 * @throws AditoJDitoException
 */
listFiles: function(pFile, pFilter){},

/**
 * @type String
 */
getReadableID: function(){}

};


emails = {

/**
 * @type Number 
 */
FORMAT_MIME: undefined,

/**
 * @type Number 
 */
MAILBRIDGE_ERROR_UNKNOWN: undefined,

/**
 * @type Number 
 */
MAILBRIDGE_ERROR_GETMESSAGE: undefined,

/**
 * @type Number 
 */
MAILBRIDGE_ERROR_GETSIZE: undefined,

/**
 * @type Number 
 */
MAILBRIDGE_ERROR_SIZETOOBIG: undefined,

/**
 * @type Number 
 */
MAILBRIDGE_ERROR_PREHANDLING: undefined,

/**
 * @type Number 
 */
MAILBRIDGE_ERROR_FILTER: undefined,

/**
 * @type Number 
 */
MAILBRIDGE_ERROR_REPOSITORY_STORE: undefined,

/**
 * @type Number 
 */
MAILBRIDGE_ERROR_PROCESS: undefined,

/**
 * @type Number 
 */
MAILBRIDGE_ERROR_POSTHANDLING: undefined,

/**
 * @type Number 
 */
MAILBRIDGE_ERROR_SERVERDELETE: undefined,

/**
 * @type Number 
 */
MAILBRIDGE_ERROR_LOG: undefined,

/**
 * @param {String} pProcess
 * @type void
 * @throws AditoJDitoException
 */
setReminderProcess: function(pProcess){},

/**
 * @type String
 * @throws AditoJDitoException
 */
newMail: function(){},

/**
 * @param {String} pUserTitle
 * @type String
 * @throws AditoJDitoException
 */
newMail: function(pUserTitle){},

/**
 * @param {String} pMailText
 * @param {Number} pMailFormat
 * @type String
 * @throws AditoJDitoException
 */
newMail: function(pMailText, pMailFormat){},

/**
 * @param {String} pMailText
 * @param {Number} pMailFormat
 * @param {String} pUserTitle
 * @type String
 * @throws AditoJDitoException
 */
newMail: function(pMailText, pMailFormat, pUserTitle){},

/**
 * @param {String} pMailID
 * @type Boolean
 */
clearMail: function(pMailID){},

/**
 * @param {String} pSender
 * @param {String} pMailID
 * @type void
 * @throws AditoJDitoException
 */
setSender: function(pSender, pMailID){},

/**
 * @param {Number} pRecipientType
 * @param {String} pMailID
 * @param {Array} pRecipients
 * @type void
 * @throws AditoJDitoException
 */
addRecipients: function(pRecipientType, pMailID, pRecipients){},

/**
 * @param {Number} pRecipientType
 * @param {String} pMailID
 * @param {String} pRecipients
 * @type void
 * @throws AditoJDitoException
 */
addRecipients: function(pRecipientType, pMailID, pRecipients){},

/**
 * @param {String} pSubject
 * @param {String} pMailID
 * @type void
 * @throws AditoJDitoException
 */
setSubject: function(pSubject, pMailID){},

/**
 * @param {String} pSubject
 * @param {String} pMailID
 * @param {String} pEncoding
 * @type void
 * @throws AditoJDitoException
 */
setSubject: function(pSubject, pMailID, pEncoding){},

/**
 * @param {String} pTextType
 * @param {String} pMailID
 * @param {String} pText
 * @type void
 * @throws AditoJDitoException
 */
addText: function(pTextType, pMailID, pText){},

/**
 * @param {String} pTextType
 * @param {String} pMailID
 * @param {String} pEncoding
 * @param {String} pText
 * @type void
 * @throws AditoJDitoException
 */
addText: function(pTextType, pMailID, pEncoding, pText){},

/**
 * @param {String} pFileName
 * @param {String} pMailID
 * @param {Boolean} pInline
 * @param {String} pContentType
 * @param {Object} pContent
 * @type void
 * @throws AditoJDitoException
 */
addAttachment: function(pFileName, pMailID, pInline, pContentType, pContent){},

/**
 * @param {String} pFileName
 * @param {String} pBase64Content
 * @param {String} pMailID
 * @param {Boolean} pInline
 * @param {String} pContentType
 * @type void
 * @throws AditoJDitoException
 */
addBase64Attachment: function(pFileName, pBase64Content, pMailID, pInline, pContentType){},

/**
 * @param {String} pFileName
 * @param {String} pMailID
 * @param {Boolean} pInline
 * @param {String} pContentType
 * @param {Array} pContent
 * @type void
 * @throws AditoJDitoException
 */
addAttachment: function(pFileName, pMailID, pInline, pContentType, pContent){},

/**
 * @param {String} pHeaderName
 * @param {String} pMailID
 * @param {String} pHeaderContent
 * @type void
 * @throws AditoJDitoException
 */
addHeader: function(pHeaderName, pMailID, pHeaderContent){},

/**
 * @param {String} pHeaderName
 * @param {String} pMailID
 * @param {String} pHeaderContent
 * @type void
 * @throws AditoJDitoException
 */
setHeader: function(pHeaderName, pMailID, pHeaderContent){},

/**
 * @param {Object} pMail
 * @type Array
 * @throws AditoJDitoException
 */
getHeaderNames: function(pMail){},

/**
 * @param {String} pName
 * @param {Object} pMail
 * @type Array
 * @throws AditoJDitoException
 */
getHeader: function(pName, pMail){},

/**
 * @param {Object} pMail
 * @type Array
 * @throws AditoJDitoException
 */
getAttachmentInfos: function(pMail){},

/**
 * @param {Number} pPosition
 * @param {Object} pMail
 * @type String
 * @throws AditoJDitoException
 */
getAttachment: function(pPosition, pMail){},

/**
 * @param {Boolean} pNewWindow
 * @param {String} pMailID
 * @type void
 * @throws AditoJDitoException
 */
editMail: function(pNewWindow, pMailID){},

/**
 * @param {Boolean} pNewWindow
 * @param {String} pMailID
 * @param {String} pUserTitle
 * @type void
 * @throws AditoJDitoException
 */
editMail: function(pNewWindow, pMailID, pUserTitle){},

/**
 * @param {String} pMailID
 * @type Object
 * @throws AditoJDitoException
 */
getCachedMail: function(pMailID){},

/**
 * @param {Boolean} pNewWindow
 * @param {String} pIdentifier
 * @type void
 * @throws AditoJDitoException
 */
openMail: function(pNewWindow, pIdentifier){},

/**
 * @param {Boolean} pNewWindow
 * @param {String} pIdentifier
 * @param {String} pUserTitle
 * @type void
 * @throws AditoJDitoException
 */
openMail: function(pNewWindow, pIdentifier, pUserTitle){},

/**
 * @param {String} pIdentifier
 * @type Boolean
 * @throws AditoJDitoException
 */
hasMail: function(pIdentifier){},

/**
 * @param {String} pIdentifier
 * @type Object
 * @throws AditoJDitoException
 */
getMail: function(pIdentifier){},

/**
 * @param {String} pIdentifier
 * @type Boolean
 * @throws AditoJDitoException
 */
deleteMail: function(pIdentifier){},

/**
 * @param {String} pMailID
 * @type Number
 * @throws AditoJDitoException
 */
sendMail: function(pMailID){},

/**
 * @param {String} pMailID
 * @param {String} pUserTitle
 * @type Number
 * @throws AditoJDitoException
 */
sendMail: function(pMailID, pUserTitle){},

/**
 * @param {String} pName
 * @type Object
 * @throws AditoJDitoException
 */
resolveMail: function(pName){},

/**
 * @type Boolean
 * @throws AditoJDitoException
 */
hasNewMessages: function(){},

/**
 * @param {String} pUserTitle
 * @type Boolean
 * @throws AditoJDitoException
 */
hasNewMessages: function(pUserTitle){},

/**
 * @type Array
 * @throws AditoJDitoException
 */
getNewMessages: function(){},

/**
 * @param {String} pUserTitle
 * @type Array
 * @throws AditoJDitoException
 */
getNewMessages: function(pUserTitle){},

/**
 * @param {String} pFolderName
 * @type Array
 * @throws AditoJDitoException
 */
getMessages: function(pFolderName){},

/**
 * @param {String} pFolderName
 * @param {String} pUserTitle
 * @type Array
 * @throws AditoJDitoException
 */
getMessages: function(pFolderName, pUserTitle){},

/**
 * @param {String} pStoredMessageInfo
 * @param {String} pFolderName
 * @type Object
 * @throws AditoJDitoException
 */
getMessage: function(pStoredMessageInfo, pFolderName){},

/**
 * @param {String} pStoredMessageInfo
 * @param {String} pFolderName
 * @param {String} pUserTitle
 * @type Object
 * @throws AditoJDitoException
 */
getMessage: function(pStoredMessageInfo, pFolderName, pUserTitle){},

/**
 * @param {Boolean} pNewWindow
 * @param {String} pStoredMessageInfo
 * @param {String} pFolderName
 * @type void
 * @throws AditoJDitoException
 */
openMessage: function(pNewWindow, pStoredMessageInfo, pFolderName){},

/**
 * @param {Boolean} pNewWindow
 * @param {String} pStoredMessageInfo
 * @param {String} pFolderName
 * @param {String} pUserTitle
 * @type void
 * @throws AditoJDitoException
 */
openMessage: function(pNewWindow, pStoredMessageInfo, pFolderName, pUserTitle){},

/**
 * @param {String} pStoredMessageInfo
 * @param {String} pFolderName
 * @type Boolean
 * @throws AditoJDitoException
 */
deleteMessage: function(pStoredMessageInfo, pFolderName){},

/**
 * @param {String} pStoredMessageInfo
 * @param {String} pFolderName
 * @param {String} pUserTitle
 * @type Boolean
 * @throws AditoJDitoException
 */
deleteMessage: function(pStoredMessageInfo, pFolderName, pUserTitle){},

/**
 * @param {String} pStoredMessageInfo
 * @param {String} pSourceFolder
 * @param {String} pDestinationFolder
 * @type Boolean
 * @throws AditoJDitoException
 */
copyMessage: function(pStoredMessageInfo, pSourceFolder, pDestinationFolder){},

/**
 * @param {String} pStoredMessageInfo
 * @param {String} pSourceFolder
 * @param {String} pUserTitle
 * @param {String} pDestinationFolder
 * @type Boolean
 * @throws AditoJDitoException
 */
copyMessage: function(pStoredMessageInfo, pSourceFolder, pUserTitle, pDestinationFolder){},

/**
 * @param {String} pStoredMessageInfo
 * @param {String} pSourceFolder
 * @param {String} pDestinationFolder
 * @type Array
 * @throws AditoJDitoException
 */
copyMessage2: function(pStoredMessageInfo, pSourceFolder, pDestinationFolder){},

/**
 * @param {String} pStoredMessageInfo
 * @param {String} pSourceFolder
 * @param {String} pUserTitle
 * @param {String} pDestinationFolder
 * @type Array
 * @throws AditoJDitoException
 */
copyMessage2: function(pStoredMessageInfo, pSourceFolder, pUserTitle, pDestinationFolder){},

/**
 * @param {String} pStoredMessageInfo
 * @param {String} pFolderName
 * @type String
 * @throws AditoJDitoException
 */
storeMessage: function(pStoredMessageInfo, pFolderName){},

/**
 * @param {String} pStoredMessageInfo
 * @param {String} pFolderName
 * @param {String} pUserTitle
 * @type String
 * @throws AditoJDitoException
 */
storeMessage: function(pStoredMessageInfo, pFolderName, pUserTitle){},

/**
 * @param {String} pAddress
 * @type String
 * @throws AditoJDitoException
 */
extractAddress: function(pAddress){},

/**
 * @type String
 */
getRepositoryAlias: function(){},

/**
 * @type String
 */
getReadableID: function(){}

};


ACTION = {

/**
 * @type Number 
 */
COMMON_RESTORELAYOUT: undefined,

/**
 * @type Number 
 */
FRAME_DATAROWFIRST: undefined,

/**
 * @type Number 
 */
FRAME_DATAROWBACKWARD: undefined,

/**
 * @type Number 
 */
FRAME_DATAROWFOREWARD: undefined,

/**
 * @type Number 
 */
FRAME_DATAROWLAST: undefined,

/**
 * @type Number 
 */
FRAME_CREATE: undefined,

/**
 * @type Number 
 */
FRAME_DELETE: undefined,

/**
 * @type Number 
 */
FRAME_EDIT: undefined,

/**
 * @type Number 
 */
FRAME_COPY: undefined,

/**
 * @type Number 
 */
FRAME_CANCEL: undefined,

/**
 * @type Number 
 */
FRAME_SAVE: undefined,

/**
 * @type Number 
 */
FRAME_NEWSELECTION: undefined,

/**
 * @type Number 
 */
FRAME_RUNSELECTION: undefined,

/**
 * @type Number 
 */
FRAME_RUNSELECTION_TABLE: undefined,

/**
 * @type Number 
 */
FRAME_DROPSELECTION_TABLE: undefined,

/**
 * @type Number 
 */
FRAME_UPDATE: undefined,

/**
 * @type Number 
 */
FRAME_TABLELIST: undefined,

/**
 * @type Number 
 */
FRAME_PRINT: undefined,

/**
 * @type Number 
 */
FRAME_PRINTPAGEDIALOG: undefined,

/**
 * @type String
 */
getReadableID: function(){}

};


log = {

/**
 * @param {Object} pObject
 * @type void
 */
log: function(pObject){},

/**
 * @param {Number} pErrorID
 * @param {Object} pObject
 * @type void
 */
log: function(pErrorID, pObject){},

/**
 * @param {Object} pObject
 * @type void
 */
show: function(pObject){},

/**
 * @param {Object} pObject
 * @param {Boolean} pFirstDetailAsMessage
 * @type void
 */
show: function(pObject, pFirstDetailAsMessage){},

/**
 * @param {Number} pErrorID
 * @param {Object} pObject
 * @type void
 */
show: function(pErrorID, pObject){},

/**
 * @param {Number} pErrorID
 * @param {Object} pObject
 * @param {Boolean} pFirstDetailAsMessage
 * @type void
 */
show: function(pErrorID, pObject, pFirstDetailAsMessage){},

/**
 * @param {Throwable} pException
 * @param {Object} pDetails
 * @param {Number} pErrorID
 * @param {Boolean} pShowDialog
 * @type void
 */
log: function(pException, pDetails, pErrorID, pShowDialog){},

/**
 * @param {Throwable} pException
 * @param {Object} pDetails
 * @param {Number} pErrorID
 * @param {Boolean} pShowDialog
 * @param {Boolean} pFirstDetailAsMessage
 * @type void
 */
log: function(pException, pDetails, pErrorID, pShowDialog, pFirstDetailAsMessage){},

/**
 * @param {Throwable} pException
 * @param {Object} pDetails
 * @param {Boolean} pShowDialog
 * @type void
 */
log: function(pException, pDetails, pShowDialog){},

/**
 * @param {Throwable} pException
 * @param {Object} pDetails
 * @param {Boolean} pShowDialog
 * @param {Boolean} pFirstDetailAsMessage
 * @type void
 */
log: function(pException, pDetails, pShowDialog, pFirstDetailAsMessage){},

/**
 * @param {Object} pDetails
 * @param {Number} pErrorID
 * @param {Boolean} pShowDialog
 * @type void
 */
log: function(pDetails, pErrorID, pShowDialog){},

/**
 * @param {Object} pDetails
 * @param {Number} pErrorID
 * @param {Boolean} pShowDialog
 * @param {Boolean} pFirstDetailAsMessage
 * @type void
 */
log: function(pDetails, pErrorID, pShowDialog, pFirstDetailAsMessage){},

/**
 * @param {Number} pErrorID
 * @param {Boolean} pShowDialog
 * @type void
 */
log: function(pErrorID, pShowDialog){},

/**
 * @param {Object} pDetails
 * @param {Boolean} pShowDialog
 * @type void
 */
log: function(pDetails, pShowDialog){},

/**
 * @param {Object} pDetails
 * @param {Boolean} pShowDialog
 * @param {Boolean} pFirstDetailAsMessage
 * @type void
 */
log: function(pDetails, pShowDialog, pFirstDetailAsMessage){},

/**
 * @param {Throwable} pException
 * @param {Object} pDetails
 * @param {Number} pErrorID
 * @param {Boolean} pShowDialog
 * @type void
 */
debug: function(pException, pDetails, pErrorID, pShowDialog){},

/**
 * @param {Throwable} pException
 * @param {Object} pDetails
 * @param {Number} pErrorID
 * @param {Boolean} pShowDialog
 * @param {Boolean} pFirstDetailAsMessage
 * @type void
 */
debug: function(pException, pDetails, pErrorID, pShowDialog, pFirstDetailAsMessage){},

/**
 * @type String
 */
getReadableID: function(){}

};


ALIAS = {

/**
 * @type String
 */
getReadableID: function(){}

};


date = {

/**
 * @type Number 
 */
ONE_SECOND: undefined,

/**
 * @type Number 
 */
ONE_MINUTE: undefined,

/**
 * @type Number 
 */
ONE_HOUR: undefined,

/**
 * @type Number 
 */
ONE_DAY: undefined,

/**
 * @type Number 
 */
ONE_WEEK: undefined,

/**
 * @type Number
 */
date: function(){},

/**
 * @param {Number} pDate
 * @type Number
 */
clearTime: function(pDate){},

/**
 * @param {String} pTimeZone
 * @param {Number} pDate
 * @type Number
 */
clearTime: function(pTimeZone, pDate){},

/**
 * @type Number
 */
today: function(){},

/**
 * @param {String} pTimeZone
 * @type Number
 */
today: function(pTimeZone){},

/**
 * @param {String} pDateAsLong
 * @type String
 * @throws AditoJDitoException
 */
longToDate: function(pDateAsLong){},

/**
 * @param {String} pPattern
 * @param {String} pDateAsLong
 * @type String
 * @throws AditoJDitoException
 */
longToDate: function(pPattern, pDateAsLong){},

/**
 * @param {String} pPattern
 * @param {String} pTimeZone
 * @param {String} pDateAsLong
 * @type String
 * @throws AditoJDitoException
 */
longToDate: function(pPattern, pTimeZone, pDateAsLong){},

/**
 * @param {String} pDate
 * @type String
 * @throws AditoJDitoException
 */
dateToLong: function(pDate){},

/**
 * @param {String} pPattern
 * @param {String} pDate
 * @type String
 * @throws AditoJDitoException
 */
dateToLong: function(pPattern, pDate){},

/**
 * @param {String} pPattern
 * @param {String} pTimeZone
 * @param {String} pDate
 * @type String
 * @throws AditoJDitoException
 */
dateToLong: function(pPattern, pTimeZone, pDate){},

/**
 * @type String
 */
getReadableID: function(){}

};


a = {

/**
 * @type Number 
 */
WINDOW_CURRENT: undefined,

/**
 * @type Number 
 */
WINDOW_NEW: undefined,

/**
 * @type Number 
 */
CLIENTCMD_OPENFILE: undefined,

/**
 * @type Number 
 */
CLIENTCMD_OPENURL: undefined,

/**
 * @type Number 
 */
CLIENTCMD_EXECUTE: undefined,

/**
 * @type Number 
 */
CLIENTCMD_EXECUTE_WAIT: undefined,

/**
 * @type Number 
 */
CLIENTCMD_STOREDATA: undefined,

/**
 * @type Number 
 */
CLIENTCMD_GETDATA: undefined,

/**
 * @type Number 
 */
CLIENTCMD_SLEEP: undefined,

/**
 * @type Number 
 */
CLIENTCMD_BEEP: undefined,

/**
 * @type Number 
 */
CLIENTCMD_TOFRONT: undefined,

/**
 * @type Number 
 */
CLIENTCMD_MESSAGE: undefined,

/**
 * @type Number 
 */
CLIENTCMD_TOCLIPBOARD: undefined,

/**
 * @type Number 
 */
CLIENTCMD_FROMCLIPBOARD: undefined,

/**
 * @type Number 
 */
CLIENTCMD_GETPROPERTY: undefined,

/**
 * @type Number 
 */
CLIENTCMD_FILEREADABLE: undefined,

/**
 * @type Number 
 */
CLIENTCMD_FILEWRITEABLE: undefined,

/**
 * @type Number 
 */
CLIENTCMD_RUNPLUGIN: undefined,

/**
 * @type Number 
 */
CLIENTCMD_FILEIO_CANREAD: undefined,

/**
 * @type Number 
 */
CLIENTCMD_FILEIO_CANWRITE: undefined,

/**
 * @type Number 
 */
CLIENTCMD_FILEIO_DELETE: undefined,

/**
 * @type Number 
 */
CLIENTCMD_FILEIO_EXISTS: undefined,

/**
 * @type Number 
 */
CLIENTCMD_FILEIO_GETABSOLUTE: undefined,

/**
 * @type Number 
 */
CLIENTCMD_FILEIO_GETLENGTH: undefined,

/**
 * @type Number 
 */
CLIENTCMD_FILEIO_GETNAME: undefined,

/**
 * @type Number 
 */
CLIENTCMD_FILEIO_GETPARENT: undefined,

/**
 * @type Number 
 */
CLIENTCMD_FILEIO_ISDIRECTORY: undefined,

/**
 * @type Number 
 */
CLIENTCMD_FILEIO_ISFILE: undefined,

/**
 * @type Number 
 */
CLIENTCMD_FILEIO_ISHIDDEN: undefined,

/**
 * @type Number 
 */
CLIENTCMD_FILEIO_LASTMODIFIED: undefined,

/**
 * @type Number 
 */
CLIENTCMD_FILEIO_MKDIR: undefined,

/**
 * @type Number 
 */
CLIENTCMD_FILEIO_RENAME: undefined,

/**
 * @type Number 
 */
CLIENTCMD_FILEIO_SETREADONLY: undefined,

/**
 * @type Number 
 */
CLIENTCMD_FILEIO_LISTFILES: undefined,

/**
 * @type Number 
 */
DATA_TEXT: undefined,

/**
 * @type Number 
 */
DATA_BINARY: undefined,

/**
 * @type Number 
 */
DBTYPE_INTERBASE7: undefined,

/**
 * @type Number 
 */
DBTYPE_ORACLE10_THIN: undefined,

/**
 * @type Number 
 */
DBTYPE_ORACLE10_OCI: undefined,

/**
 * @type Number 
 */
DBTYPE_ORACLE10_CLUSTER: undefined,

/**
 * @type Number 
 */
DBTYPE_SQLSERVER2000: undefined,

/**
 * @type Number 
 */
DBTYPE_MYSQL4: undefined,

/**
 * @type Number 
 */
DBTYPE_SYBASE125: undefined,

/**
 * @type Number 
 */
DBTYPE_DERBY10: undefined,

/**
 * @type Number 
 */
DBTYPE_POSTGRESQL8: undefined,

/**
 * @type Number 
 */
DBTYPE_FIREBIRD250: undefined,

/**
 * @type Number 
 */
DATAMODEL_KIND_FRAME: undefined,

/**
 * @type Number 
 */
DATAMODEL_KIND_ALIAS: undefined,

/**
 * @type Number 
 */
DATAMODEL_KIND_PROCESS: undefined,

/**
 * @type Number 
 */
DATAMODEL_KIND_REPORT: undefined,

/**
 * @type String 
 */
ALIAS_NAME: undefined,

/**
 * @type String 
 */
ALIAS_DATASOURCETYPE: undefined,

/**
 * @type String 
 */
ALIAS_PROPERTIES: undefined,

/**
 * @type Object 
 */
SQL_COMPLETE: undefined,

/**
 * @type Number 
 */
SQL_ROW: undefined,

/**
 * @type Number 
 */
SQL_COLUMN: undefined,

/**
 * @type String 
 */
EMPTY_TABLE_SQL: undefined,

/**
 * @type Number 
 */
REPORT_OPEN: undefined,

/**
 * @type Number 
 */
REPORT_PRINT: undefined,

/**
 * @type Number 
 */
REPORT_EXPORT: undefined,

/**
 * @type Number 
 */
REPORT_EXPORT_CSV: undefined,

/**
 * @type Number 
 */
REPORT_EXPORT_HTML: undefined,

/**
 * @type Number 
 */
REPORT_EXPORT_PDF: undefined,

/**
 * @type Number 
 */
REPORT_EXPORT_RTF: undefined,

/**
 * @type Number 
 */
REPORT_EXPORT_XLS: undefined,

/**
 * @type Number 
 */
REPORT_EXPORT_XML: undefined,

/**
 * @type Number 
 */
REPORT_EXPORT_SVG: undefined,

/**
 * @type Number 
 */
REPORT_EXPORT_PS: undefined,

/**
 * @type Number 
 */
REPORT_EXPORT_PS2: undefined,

/**
 * @type Number 
 */
REPORT_EXPORT_PS3: undefined,

/**
 * @type Number 
 */
REPORT_EXPORT_TXT: undefined,

/**
 * @type Number 
 */
REPORT_EXPORT_BMP: undefined,

/**
 * @type Number 
 */
REPORT_EXPORT_PNG: undefined,

/**
 * @type Number 
 */
REPORT_EXPORT_JPG: undefined,

/**
 * @type Number 
 */
REPORT_EXPORT_GIF: undefined,

/**
 * @type Number 
 */
ONE_SECOND: undefined,

/**
 * @type Number 
 */
ONE_MINUTE: undefined,

/**
 * @type Number 
 */
ONE_HOUR: undefined,

/**
 * @type Number 
 */
ONE_DAY: undefined,

/**
 * @type Number 
 */
ONE_WEEK: undefined,

/**
 * @type Number 
 */
TIMERTYPE_CLIENT_RUN: undefined,

/**
 * @type Number 
 */
TIMERTYPE_SERVER: undefined,

/**
 * @type Number 
 */
TIMERTYPE_SERVER_RUN: undefined,

/**
 * @type Number 
 */
TIMERTYPE_CLUSTER: undefined,

/**
 * @type Number 
 */
ESCAPEMODE_ESCAPE: undefined,

/**
 * @type Number 
 */
ESCAPEMODE_DOUBLE: undefined,

/**
 * @type Number 
 */
ESCAPEMODE_CHANGE: undefined,

/**
 * @type Number 
 */
ESCAPEMODE_NOTHING: undefined,

/**
 * @type Number 
 */
QUESTION_OK: undefined,

/**
 * @type Number 
 */
QUESTION_YESNO: undefined,

/**
 * @type Number 
 */
QUESTION_YESNOCANCEL: undefined,

/**
 * @type Number 
 */
QUESTION_COMBOBOX: undefined,

/**
 * @type Number 
 */
QUESTION_EDIT: undefined,

/**
 * @type Number 
 */
QUESTION_FILECHOOSER: undefined,

/**
 * @type Number 
 */
QUESTION_DIRECTORYCHOOSER: undefined,

/**
 * @type Number 
 */
QUESTION_USER: undefined,

/**
 * @type Number 
 */
INSERTED: undefined,

/**
 * @type Number 
 */
UPDATED: undefined,

/**
 * @type Number 
 */
DELETED: undefined,

/**
 * @type Number 
 */
ALL: undefined,

/**
 * @type Boolean 
 */
SELECTION_OR: undefined,

/**
 * @type Boolean 
 */
SELECTION_AND: undefined,

/**
 * @type Number 
 */
SYSTEMTRAY_NONE: undefined,

/**
 * @type Number 
 */
SYSTEMTRAY_INFO: undefined,

/**
 * @type Number 
 */
SYSTEMTRAY_WARNING: undefined,

/**
 * @type Number 
 */
SYSTEMTRAY_ERROR: undefined,

/**
 * @type Number 
 */
EXPORT_APPEND: undefined,

/**
 * @type Number 
 */
EXPORT_ABORT: undefined,

/**
 * @type Number 
 */
EXPORT_OVERWRITE: undefined,

/**
 * @type Number 
 */
FRAMEMODE_SHOW: undefined,

/**
 * @type Number 
 */
FRAMEMODE_SEARCH: undefined,

/**
 * @type Number 
 */
FRAMEMODE_NEW: undefined,

/**
 * @type Number 
 */
FRAMEMODE_EDIT: undefined,

/**
 * @type Number 
 */
FRAMEMODE_TABLE: undefined,

/**
 * @type Number 
 */
FRAMEMODE_TABLE_SELECTION: undefined,

/**
 * @type Number 
 */
IMAGE_TYPE_FRAME: undefined,

/**
 * @type Number 
 */
IMAGE_TYPE_MAIL: undefined,

/**
 * @type Number 
 */
IMAGE_TYPE_CALENDAR: undefined,

/**
 * @type Number 
 */
IMAGE_TYPE_REPORT: undefined,

/**
 * @type Number 
 */
WINDOWPOSITION_DEFAULT: undefined,

/**
 * @type Number 
 */
WINDOWPOSITION_CENTERONSCREEN: undefined,

/**
 * @type Number 
 */
WINDOWPOSITION_CENTERONWINDOW: undefined,

/**
 * @type Number 
 */
CONDITION_STATIC: undefined,

/**
 * @type Number 
 */
CONDITION_DESIGNER: undefined,

/**
 * @type Number 
 */
CONDITION_SEARCHMASK: undefined,

/**
 * @type Number 
 */
CONDITION_LINK: undefined,

/**
 * @type Number 
 */
CONDITION_EXTRA: undefined,

/**
 * @type String 
 */
OPERATOR_EQUAL: undefined,

/**
 * @type String 
 */
OPERATOR_NOT_EQUAL: undefined,

/**
 * @type String 
 */
OPERATOR_GREATER: undefined,

/**
 * @type String 
 */
OPERATOR_LESS: undefined,

/**
 * @type String 
 */
OPERATOR_LESS_OR_EQUAL: undefined,

/**
 * @type String 
 */
OPERATOR_GREATER_OR_EQUAL: undefined,

/**
 * @type String 
 */
OPERATOR_LIKE: undefined,

/**
 * @type String 
 */
OPERATOR_NOT_LIKE: undefined,

/**
 * @type String 
 */
OPERATOR_NOT_NULL: undefined,

/**
 * @type String 
 */
OPERATOR_NULL: undefined,

/**
 * @type String 
 */
OPERATOR_NOT_IN: undefined,

/**
 * @type String 
 */
OPERATOR_IN: undefined,

/**
 * @type String 
 */
SEARCHLINK_CONDITION: undefined,

/**
 * @param {String} pReturn
 * @type void
 */
returndynamic: function(pReturn){},

/**
 * @param {String} pReturn
 * @type void
 */
rd: function(pReturn){},

/**
 * @param {String} pReturn
 * @type void
 */
returnstatic: function(pReturn){},

/**
 * @param {String} pReturn
 * @type void
 */
rs: function(pReturn){},

/**
 * @param {String} pReturn
 * @type void
 */
returnquery: function(pReturn){},

/**
 * @param {String} pReturn
 * @type void
 */
rq: function(pReturn){},

/**
 * @param {String} pAlias
 * @param {String} pReturn
 * @type void
 */
rq: function(pAlias, pReturn){},

/**
 * @param {String} pAlias
 * @param {String} pReturn
 * @type void
 */
returnquery: function(pAlias, pReturn){},

/**
 * @param {String} pReturn
 * @type void
 */
returnstaticquery: function(pReturn){},

/**
 * @param {String} pReturn
 * @type void
 */
rsq: function(pReturn){},

/**
 * @param {String} pAlias
 * @param {String} pReturn
 * @type void
 */
rsq: function(pAlias, pReturn){},

/**
 * @param {String} pAlias
 * @param {String} pReturn
 * @type void
 */
returnstaticquery: function(pAlias, pReturn){},

/**
 * @param {Object} pQuery
 * @type void
 * @throws AditoJDitoException
 */
rpq: function(pQuery){},

/**
 * @param {Object} pQuery
 * @type void
 * @throws AditoJDitoException
 */
returnpreparedquery: function(pQuery){},

/**
 * @param {String} pAlias
 * @param {Object} pQuery
 * @type void
 * @throws AditoJDitoException
 */
rpq: function(pAlias, pQuery){},

/**
 * @param {String} pAlias
 * @param {Object} pQuery
 * @type void
 * @throws AditoJDitoException
 */
returnpreparedquery: function(pAlias, pQuery){},

/**
 * @param {Object} pReturn
 * @type void
 */
ro: function(pReturn){},

/**
 * @param {Object} pReturn
 * @type void
 */
returnobject: function(pReturn){},

/**
 * @param {Object} pValue
 * @param {String} pName
 * @type void
 * @throws AditoJDitoException
 */
localvar: function(pValue, pName){},

/**
 * @param {Object} pValue
 * @param {String} pName
 * @type void
 * @throws AditoJDitoException
 */
imagevar: function(pValue, pName){},

/**
 * @param {Object} pValue
 * @param {String} pName
 * @type void
 * @throws AditoJDitoException
 */
globalvar: function(pValue, pName){},

/**
 * @param {Object} pValue
 * @param {String} pName
 * @type void
 * @throws AditoJDitoException
 */
setvar: function(pValue, pName){},

/**
 * @param {String} pName
 * @type String
 * @throws AditoJDitoException
 */
valueof: function(pName){},

/**
 * @param {String} pName
 * @type Object
 * @throws AditoJDitoException
 */
valueofObj: function(pName){},

/**
 * @param {String} pName
 * @type Boolean
 * @throws AditoJDitoException
 */
hasvar: function(pName){},

/**
 * @param {String} pValue
 * @param {String} pFieldName
 * @type void
 * @throws AditoJDitoException
 */
setValue: function(pValue, pFieldName){},

/**
 * @param {String} pValue
 * @param {String} pImageID
 * @param {String} pFieldName
 * @param {String} pWindowID
 * @type void
 * @throws AditoJDitoException
 */
setValue: function(pValue, pImageID, pFieldName, pWindowID){},

/**
 * @param {Object} pKeyValues
 * @type void
 * @throws AditoJDitoException
 */
setValues: function(pKeyValues){},

/**
 * @param {Object} pKeyValues
 * @param {String} pImageID
 * @param {String} pWindowID
 * @type void
 * @throws AditoJDitoException
 */
setValues: function(pKeyValues, pImageID, pWindowID){},

/**
 * @type void
 * @throws AditoJDitoException
 */
closeCurrentTopImage: function(){},

/**
 * @type Boolean
 * @throws AditoJDitoException
 */
closeAllowed: function(){},

/**
 * @param {String} pImageID
 * @param {String} pWindowID
 * @type Boolean
 * @throws AditoJDitoException
 */
closeAllowed: function(pImageID, pWindowID){},

/**
 * @type String
 * @throws AditoJDitoException
 */
getCurrentImageContent: function(){},

/**
 * @param {String} pImageID
 * @param {String} pWindowID
 * @type String
 * @throws AditoJDitoException
 */
getImageContent: function(pImageID, pWindowID){},

/**
 * @param {String} pImageID
 * @param {String} pWindowID
 * @type Boolean
 * @throws AditoJDitoException
 */
existsImage: function(pImageID, pWindowID){},

/**
 * @param {String} pImageID
 * @param {String} pWindowID
 * @type void
 * @throws AditoJDitoException
 */
closeTopImage: function(pImageID, pWindowID){},

/**
 * @param {Number} pFrameMode
 * @param {Boolean} pNewWindow
 * @param {String} pName
 * @param {Object} pCondition
 * @type String
 * @throws AditoJDitoException
 */
openFrame: function(pFrameMode, pNewWindow, pName, pCondition){},

/**
 * @param {Number} pFrameMode
 * @param {Boolean} pNewWindow
 * @param {String} pName
 * @param {Array} pWindowDetails
 * @param {Object} pCondition
 * @type String
 * @throws AditoJDitoException
 */
openFrame: function(pFrameMode, pNewWindow, pName, pWindowDetails, pCondition){},

/**
 * @param {Number} pFrameMode
 * @param {Boolean} pNewWindow
 * @param {String} pName
 * @param {Boolean} pResetConditionAtSearch
 * @param {Array} pWindowDetails
 * @param {Object} pCondition
 * @type String
 * @throws AditoJDitoException
 */
openFrame: function(pFrameMode, pNewWindow, pName, pResetConditionAtSearch, pWindowDetails, pCondition){},

/**
 * @param {Number} pFrameMode
 * @param {String} pName
 * @param {Boolean} pResetConditionAtSearch
 * @param {Array} pWindowDetails
 * @param {Number} pWindowMode
 * @param {Object} pCondition
 * @type String
 * @throws AditoJDitoException
 */
openFrame: function(pFrameMode, pName, pResetConditionAtSearch, pWindowDetails, pWindowMode, pCondition){},

/**
 * @param {Object} pPrompts
 * @param {Number} pFrameMode
 * @param {Boolean} pNewWindow
 * @param {String} pName
 * @param {Boolean} pResetConditionAtSearch
 * @param {Array} pWindowDetails
 * @param {Object} pCondition
 * @type String
 * @throws AditoJDitoException
 */
openFrame: function(pPrompts, pFrameMode, pNewWindow, pName, pResetConditionAtSearch, pWindowDetails, pCondition){},

/**
 * @param {Number} pFrameMode
 * @param {Boolean} pNewWindow
 * @param {String} pName
 * @param {String} pLinks
 * @param {Object} pCondition
 * @type String
 * @throws AditoJDitoException
 */
openLinkedFrame: function(pFrameMode, pNewWindow, pName, pLinks, pCondition){},

/**
 * @param {Number} pFrameMode
 * @param {Boolean} pNewWindow
 * @param {String} pName
 * @param {Array} pWindowDetails
 * @param {String} pLinks
 * @param {Object} pCondition
 * @type String
 * @throws AditoJDitoException
 */
openLinkedFrame: function(pFrameMode, pNewWindow, pName, pWindowDetails, pLinks, pCondition){},

/**
 * @param {Number} pFrameMode
 * @param {Boolean} pNewWindow
 * @param {String} pName
 * @param {Boolean} pResetConditionAtSearch
 * @param {Array} pWindowDetails
 * @param {String} pLinks
 * @param {Object} pCondition
 * @type String
 * @throws AditoJDitoException
 */
openLinkedFrame: function(pFrameMode, pNewWindow, pName, pResetConditionAtSearch, pWindowDetails, pLinks, pCondition){},

/**
 * @param {Number} pFrameMode
 * @param {String} pName
 * @param {Boolean} pResetConditionAtSearch
 * @param {Array} pWindowDetails
 * @param {Number} pWindowMode
 * @param {String} pLinks
 * @param {Object} pCondition
 * @type String
 * @throws AditoJDitoException
 */
openLinkedFrame: function(pFrameMode, pName, pResetConditionAtSearch, pWindowDetails, pWindowMode, pLinks, pCondition){},

/**
 * @param {Object} pPrompts
 * @param {Number} pFrameMode
 * @param {Boolean} pNewWindow
 * @param {String} pName
 * @param {Boolean} pResetConditionAtSearch
 * @param {Array} pWindowDetails
 * @param {String} pLinks
 * @param {Object} pCondition
 * @type String
 * @throws AditoJDitoException
 */
openLinkedFrame: function(pPrompts, pFrameMode, pNewWindow, pName, pResetConditionAtSearch, pWindowDetails, pLinks, pCondition){},

/**
 * @param {Array} pDetails
 * @param {Number} pType
 * @type void
 * @throws AditoJDitoException
 */
doClientCommand: function(pDetails, pType){},

/**
 * @param {Array} pDetails
 * @param {Number} pType
 * @type Object
 * @throws AditoJDitoException
 */
doClientIntermediate: function(pDetails, pType){},

/**
 * @param {Object} pCondition
 * @type void
 * @throws AditoJDitoException
 */
setImageCondition: function(pCondition){},

/**
 * @param {String} pEncoded
 * @type String
 * @throws AditoJDitoException
 */
decodeFirst: function(pEncoded){},

/**
 * @param {String} pEncoded
 * @type Array
 * @throws AditoJDitoException
 */
decodeMS: function(pEncoded){},

/**
 * @param {Array} pDecoded
 * @type String
 * @throws AditoJDitoException
 */
encodeMS: function(pDecoded){},

/**
 * @param {String} pCode
 * @type String
 * @throws AditoJDitoException
 */
resolveVariables: function(pCode){},

/**
 * @param {String} pAlias
 * @type Number
 * @throws AditoJDitoException
 */
getDatabaseType: function(pAlias){},

/**
 * @param {Number} pKind
 * @type Array
 * @throws AditoJDitoException
 */
getDataModels: function(pKind){},

/**
 * @param {String} pName
 * @param {Number} pKind
 * @type Array
 * @throws AditoJDitoException
 */
getDataModel: function(pName, pKind){},

/**
 * @param {Object} pNames
 * @param {Number} pKind
 * @type Array
 * @throws AditoJDitoException
 */
getDataModels: function(pNames, pKind){},

/**
 * @param {String} pName
 * @type Object
 * @throws AditoJDitoException
 */
getAliasModel: function(pName){},

/**
 * @param {String} pName
 * @param {Number} pKind
 * @type String
 * @throws AditoJDitoException
 */
getAlias: function(pName, pKind){},

/**
 * @param {String} pAlias
 * @type Array
 * @throws AditoJDitoException
 */
getTables: function(pAlias){},

/**
 * @param {String} pAlias
 * @param {String} pTable
 * @type Array
 * @throws AditoJDitoException
 */
getColumns: function(pAlias, pTable){},

/**
 * @param {String} pAlias
 * @param {Array} pColumnNames
 * @param {String} pTable
 * @type Array
 * @throws AditoJDitoException
 */
getColumnTypes: function(pAlias, pColumnNames, pTable){},

/**
 * @param {Array} pColumnNames
 * @param {String} pTable
 * @type Array
 * @throws AditoJDitoException
 */
getColumnTypes: function(pColumnNames, pTable){},

/**
 * @param {String} pAlias
 * @param {String} pIDColumn
 * @param {String} pTable
 * @type String
 * @throws AditoException
 */
getNewID: function(pAlias, pIDColumn, pTable){},

/**
 * @param {String} pIDColumn
 * @param {String} pTable
 * @type String
 * @throws AditoException
 */
getNewID: function(pIDColumn, pTable){},

/**
 * @param {Object} pSQL
 * @type String
 * @throws AditoJDitoException
 */
sql: function(pSQL){},

/**
 * @param {String} pAlias
 * @param {Object} pSQL
 * @type String
 * @throws AditoJDitoException
 */
sql: function(pAlias, pSQL){},

/**
 * @param {SqlModeWrapper} pResultMode
 * @param {Object} pSQL
 * @type Array
 * @throws AditoJDitoException
 */
sql: function(pResultMode, pSQL){},

/**
 * @param {SqlModeWrapper} pResultMode
 * @param {Object} pSQL
 * @param {Number} pMaxRows
 * @type Array
 * @throws AditoJDitoException
 */
sql: function(pResultMode, pSQL, pMaxRows){},

/**
 * @param {String} pAlias
 * @param {SqlModeWrapper} pResultMode
 * @param {Object} pSQL
 * @type Array
 * @throws AditoJDitoException
 */
sql: function(pAlias, pResultMode, pSQL){},

/**
 * @param {String} pAlias
 * @param {SqlModeWrapper} pResultMode
 * @param {Object} pSQL
 * @param {Number} pMaxRows
 * @type Array
 * @throws AditoJDitoException
 */
sql: function(pAlias, pResultMode, pSQL, pMaxRows){},

/**
 * @param {Number} pResultMode
 * @param {Object} pSQL
 * @type Array
 * @throws AditoJDitoException
 */
sql: function(pResultMode, pSQL){},

/**
 * @param {Number} pResultMode
 * @param {Object} pSQL
 * @param {Number} pMaxRows
 * @type Array
 * @throws AditoJDitoException
 */
sql: function(pResultMode, pSQL, pMaxRows){},

/**
 * @param {String} pAlias
 * @param {Number} pResultMode
 * @param {Object} pSQL
 * @type Array
 * @throws AditoJDitoException
 */
sql: function(pAlias, pResultMode, pSQL){},

/**
 * @param {String} pAlias
 * @param {Number} pResultMode
 * @param {Object} pSQL
 * @param {Number} pMaxRows
 * @type Array
 * @throws AditoJDitoException
 */
sql: function(pAlias, pResultMode, pSQL, pMaxRows){},

/**
 * @param {String} pAlias
 * @param {Array} pColumns
 * @param {String} pTableName
 * @param {Array} pColumnTypes
 * @param {Array} pValues
 * @type Number
 * @throws AditoJDitoException
 */
getRowCount: function(pAlias, pColumns, pTableName, pColumnTypes, pValues){},

/**
 * @param {Array} pColumns
 * @param {String} pTableName
 * @param {Array} pColumnTypes
 * @param {Array} pValues
 * @type Number
 * @throws AditoJDitoException
 */
getRowCount: function(pColumns, pTableName, pColumnTypes, pValues){},

/**
 * @param {Array} pColumns
 * @param {String} pTableName
 * @param {Array} pColumnTypes
 * @param {Array} pValues
 * @type Number
 * @throws AditoJDitoException
 */
sqlInsert: function(pColumns, pTableName, pColumnTypes, pValues){},

/**
 * @param {String} pAlias
 * @param {Array} pColumns
 * @param {String} pTableName
 * @param {Array} pColumnTypes
 * @param {Array} pValues
 * @type Number
 * @throws AditoJDitoException
 */
sqlInsert: function(pAlias, pColumns, pTableName, pColumnTypes, pValues){},

/**
 * @param {Array} pStatements
 * @type Number
 * @throws AditoJDitoException
 */
sqlInsert: function(pStatements){},

/**
 * @param {String} pAlias
 * @param {Array} pStatements
 * @type Number
 * @throws AditoJDitoException
 */
sqlInsert: function(pAlias, pStatements){},

/**
 * @param {Array} pColumns
 * @param {String} pTableName
 * @param {Array} pColumnTypes
 * @param {Array} pValues
 * @param {Object} pCondition
 * @type Number
 * @throws AditoJDitoException
 */
sqlUpdate: function(pColumns, pTableName, pColumnTypes, pValues, pCondition){},

/**
 * @param {String} pAlias
 * @param {Array} pColumns
 * @param {String} pTableName
 * @param {Array} pColumnTypes
 * @param {Array} pValues
 * @param {Object} pCondition
 * @type Number
 * @throws AditoJDitoException
 */
sqlUpdate: function(pAlias, pColumns, pTableName, pColumnTypes, pValues, pCondition){},

/**
 * @param {Array} pStatements
 * @type Number
 * @throws AditoJDitoException
 */
sqlUpdate: function(pStatements){},

/**
 * @param {String} pAlias
 * @param {Array} pStatements
 * @type Number
 * @throws AditoJDitoException
 */
sqlUpdate: function(pAlias, pStatements){},

/**
 * @param {Array} pStatements
 * @type Number
 * @throws AditoJDitoException
 */
sqlMix: function(pStatements){},

/**
 * @param {String} pAlias
 * @param {Array} pStatements
 * @type Number
 * @throws AditoJDitoException
 */
sqlMix: function(pAlias, pStatements){},

/**
 * @param {String} pTableName
 * @param {Object} pCondition
 * @type Number
 * @throws AditoJDitoException
 */
sqlDelete: function(pTableName, pCondition){},

/**
 * @param {String} pAlias
 * @param {String} pTableName
 * @param {Object} pCondition
 * @type Number
 * @throws AditoJDitoException
 */
sqlDelete: function(pAlias, pTableName, pCondition){},

/**
 * @param {Array} pStatements
 * @type Number
 * @throws AditoJDitoException
 */
sqlDelete: function(pStatements){},

/**
 * @param {String} pAlias
 * @param {Array} pStatements
 * @type Number
 * @throws AditoJDitoException
 */
sqlDelete: function(pAlias, pStatements){},

/**
 * @param {String} pValue
 * @type String
 * @throws AditoJDitoException
 */
quoteDBValue: function(pValue){},

/**
 * @param {String} pAlias
 * @param {String} pValue
 * @type String
 * @throws AditoJDitoException
 */
quoteDBValue: function(pAlias, pValue){},

/**
 * @type void
 * @throws AditoJDitoException
 */
refresh: function(){},

/**
 * @param {String} pImageID
 * @param {String} pWindowID
 * @type void
 * @throws AditoJDitoException
 */
refresh: function(pImageID, pWindowID){},

/**
 * @param {Array} pModeDetails
 * @param {Boolean} pNewWindow
 * @param {String} pName
 * @param {Number} pMode
 * @param {Object} pCondition
 * @type void
 * @throws AditoJDitoException
 */
openReport: function(pModeDetails, pNewWindow, pName, pMode, pCondition){},

/**
 * @param {Array} pModeDetails
 * @param {Object} pPrompts
 * @param {Boolean} pNewWindow
 * @param {String} pName
 * @param {Number} pMode
 * @param {Object} pCondition
 * @type void
 * @throws AditoJDitoException
 */
openReport: function(pModeDetails, pPrompts, pNewWindow, pName, pMode, pCondition){},

/**
 * @param {Array} pModeDetails
 * @param {Object} pPrompts
 * @param {String} pName
 * @param {Number} pMode
 * @param {Number} pWindowMode
 * @param {Object} pCondition
 * @type void
 * @throws AditoJDitoException
 */
openReport: function(pModeDetails, pPrompts, pName, pMode, pWindowMode, pCondition){},

/**
 * @param {Array} pModeDetails
 * @param {Boolean} pNewWindow
 * @param {Array} pColumnNames
 * @param {String} pName
 * @param {Number} pMode
 * @param {Array} pData
 * @type void
 * @throws AditoJDitoException
 */
openStaticReport: function(pModeDetails, pNewWindow, pColumnNames, pName, pMode, pData){},

/**
 * @param {Array} pModeDetails
 * @param {Array} pColumnNames
 * @param {String} pName
 * @param {Number} pMode
 * @param {Array} pData
 * @param {Number} pWindowMode
 * @type void
 * @throws AditoJDitoException
 */
openStaticReport: function(pModeDetails, pColumnNames, pName, pMode, pData, pWindowMode){},

/**
 * @param {Array} pModeDetails
 * @param {Object} pPrompts
 * @param {Boolean} pNewWindow
 * @param {Array} pColumnNames
 * @param {String} pName
 * @param {Number} pMode
 * @param {Array} pData
 * @type void
 * @throws AditoJDitoException
 */
openStaticReport: function(pModeDetails, pPrompts, pNewWindow, pColumnNames, pName, pMode, pData){},

/**
 * @param {Array} pModeDetails
 * @param {Object} pPrompts
 * @param {Array} pColumnNames
 * @param {String} pName
 * @param {Number} pMode
 * @param {Array} pData
 * @param {Number} pWindowMode
 * @type void
 * @throws AditoJDitoException
 */
openStaticReport: function(pModeDetails, pPrompts, pColumnNames, pName, pMode, pData, pWindowMode){},

/**
 * @param {Array} pModeDetails
 * @param {Boolean} pNewWindow
 * @param {String} pName
 * @param {Number} pMode
 * @param {String} pWhereOrder
 * @param {Object} pCondition
 * @type String
 * @throws AditoJDitoException
 */
openLinkedReport: function(pModeDetails, pNewWindow, pName, pMode, pWhereOrder, pCondition){},

/**
 * @param {Array} pModeDetails
 * @param {Object} pPrompts
 * @param {Boolean} pNewWindow
 * @param {String} pName
 * @param {Number} pMode
 * @param {String} pWhereOrder
 * @param {Object} pCondition
 * @type String
 * @throws AditoJDitoException
 */
openLinkedReport: function(pModeDetails, pPrompts, pNewWindow, pName, pMode, pWhereOrder, pCondition){},

/**
 * @param {Array} pModeDetails
 * @param {Object} pPrompts
 * @param {Boolean} pNewWindow
 * @param {Array} pColumnNames
 * @param {String} pName
 * @param {Number} pMode
 * @param {Array} pData
 * @type String
 * @throws AditoJDitoException
 */
openStaticLinkedReport: function(pModeDetails, pPrompts, pNewWindow, pColumnNames, pName, pMode, pData){},

/**
 * @param {Array} pModeDetails
 * @param {Object} pPrompts
 * @param {String} pName
 * @param {Number} pMode
 * @param {Number} pWindowMode
 * @param {String} pWhereOrder
 * @param {Object} pCondition
 * @type String
 * @throws AditoJDitoException
 */
openLinkedReport: function(pModeDetails, pPrompts, pName, pMode, pWindowMode, pWhereOrder, pCondition){},

/**
 * @param {Array} pModeDetails
 * @param {Object} pPrompts
 * @param {Array} pColumnNames
 * @param {String} pName
 * @param {Number} pMode
 * @param {Array} pData
 * @param {Number} pWindowMode
 * @type String
 * @throws AditoJDitoException
 */
openStaticLinkedReport: function(pModeDetails, pPrompts, pColumnNames, pName, pMode, pData, pWindowMode){},

/**
 * @param {Object} pPrompts
 * @param {Array} pColumnNames
 * @param {String} pReportName
 * @param {Array} pData
 * @param {String} pWhereOrder
 * @param {Number} pExportFormat
 * @param {Object} pCondition
 * @type String
 * @throws AditoJDitoException
 */
exportReportToBytes: function(pPrompts, pColumnNames, pReportName, pData, pWhereOrder, pExportFormat, pCondition){},

/**
 * @param {Object} pPrompts
 * @param {Boolean} pWaitFor
 * @param {Array} pColumnNames
 * @param {String} pReportName
 * @param {String} pIdentifier
 * @param {Array} pData
 * @param {String} pExportFile
 * @param {String} pWhereOrder
 * @param {Number} pExportFormat
 * @param {Object} pCondition
 * @type void
 * @throws AditoJDitoException
 */
exportReportToFile: function(pPrompts, pWaitFor, pColumnNames, pReportName, pIdentifier, pData, pExportFile, pWhereOrder, pExportFormat, pCondition){},

/**
 * @param {String} pComponentName
 * @type void
 * @throws AditoJDitoException
 */
setFocus: function(pComponentName){},

/**
 * @param {String} pComponentName
 * @param {String} pImageID
 * @param {String} pWindowID
 * @type void
 * @throws AditoJDitoException
 */
setFocus: function(pComponentName, pImageID, pWindowID){},

/**
 * @param {String} pGroup
 * @type Boolean
 */
checkGroup: function(pGroup){},

/**
 * @param {String} pDateAsLong
 * @type String
 * @throws AditoJDitoException
 */
longToDate: function(pDateAsLong){},

/**
 * @param {String} pPattern
 * @param {String} pDateAsLong
 * @type String
 * @throws AditoJDitoException
 */
longToDate: function(pPattern, pDateAsLong){},

/**
 * @param {String} pDate
 * @type String
 * @throws AditoJDitoException
 */
dateToLong: function(pDate){},

/**
 * @param {String} pPattern
 * @param {String} pDate
 * @type String
 * @throws AditoJDitoException
 */
dateToLong: function(pPattern, pDate){},

/**
 * @param {String} pString
 * @type Number
 * @throws AditoJDitoException
 */
strToDouble: function(pString){},

/**
 * @param {String} pString
 * @type Number
 * @throws AditoJDitoException
 */
strToLong: function(pString){},

/**
 * @param {String} pPattern
 * @param {String} pLong
 * @type String
 * @throws AditoJDitoException
 */
formatLong: function(pPattern, pLong){},

/**
 * @param {String} pPattern
 * @param {String} pFormatted
 * @type Number
 * @throws AditoJDitoException
 */
parseLong: function(pPattern, pFormatted){},

/**
 * @param {String} pPattern
 * @param {String} pLong
 * @type String
 * @throws AditoJDitoException
 */
formatDouble: function(pPattern, pLong){},

/**
 * @param {String} pPattern
 * @param {String} pFormatted
 * @type Number
 * @throws AditoJDitoException
 */
parseDouble: function(pPattern, pFormatted){},

/**
 * @param {String} pFileName
 * @type String
 */
getMimeType: function(pFileName){},

/**
 * @param {String} pUnzippedBytes
 * @type String
 * @throws AditoJDitoException
 */
gzip: function(pUnzippedBytes){},

/**
 * @param {String} pZippedBytes
 * @type String
 * @throws AditoJDitoException
 */
gunzip: function(pZippedBytes){},

/**
 * @param {String} pOrginalBytes
 * @type String
 * @throws AditoJDitoException
 */
zip: function(pOrginalBytes){},

/**
 * @param {String} pCompressedBytes
 * @type String
 * @throws AditoJDitoException
 */
unzip: function(pCompressedBytes){},

/**
 * @param {String} pOrginalBytes
 * @type String
 * @throws AditoJDitoException
 */
deflate: function(pOrginalBytes){},

/**
 * @param {String} pCompressedBytes
 * @type String
 * @throws AditoJDitoException
 */
inflate: function(pCompressedBytes){},

/**
 * @param {String} pName
 * @type String
 * @throws AditoJDitoException
 */
executeProcess: function(pName){},

/**
 * @param {String} pName
 * @param {Object} pLocalVariables
 * @type String
 * @throws AditoJDitoException
 */
executeProcess: function(pName, pLocalVariables){},

/**
 * @param {Number} pInterval
 * @param {String} pName
 * @param {Boolean} pRunImmediately
 * @param {String} pIdentifier
 * @param {Boolean} pShowErrorDialog
 * @param {Number} pTimerType
 * @type void
 * @throws AditoJDitoException
 */
executeProcessTimer: function(pInterval, pName, pRunImmediately, pIdentifier, pShowErrorDialog, pTimerType){},

/**
 * @param {Number} pInterval
 * @param {String} pName
 * @param {Boolean} pRunImmediately
 * @param {String} pIdentifier
 * @param {Boolean} pShowErrorDialog
 * @param {Number} pTimerType
 * @param {String} pUser
 * @type void
 * @throws AditoJDitoException
 */
executeProcessTimer: function(pInterval, pName, pRunImmediately, pIdentifier, pShowErrorDialog, pTimerType, pUser){},

/**
 * @param {Number} pInterval
 * @param {String} pName
 * @param {Boolean} pRunImmediately
 * @param {String} pIdentifier
 * @param {Boolean} pShowErrorDialog
 * @param {Boolean} pKeepJDito
 * @param {Number} pTimerType
 * @param {String} pUser
 * @type void
 * @throws AditoJDitoException
 */
executeProcessTimer: function(pInterval, pName, pRunImmediately, pIdentifier, pShowErrorDialog, pKeepJDito, pTimerType, pUser){},

/**
 * @param {String} pIdentifier
 * @type Boolean
 * @throws AditoJDitoException
 */
existsProcessTimer: function(pIdentifier){},

/**
 * @param {String} pIdentifier
 * @type void
 * @throws AditoJDitoException
 */
stopProcessTimer: function(pIdentifier){},

/**
 * @type Array
 * @throws AditoJDitoException
 */
getActiveTimers: function(){},

/**
 * @param {String} pAlias
 * @param {String} pFieldDivider
 * @param {Boolean} pWaitFor
 * @param {String} pFile
 * @param {String} pTitle
 * @param {Object} pStatement
 * @param {Boolean} pWithFieldIdentifier
 * @param {String} pFieldLimiter
 * @param {String} pSentenceDivider
 * @param {Number} pHandleOldFile
 * @type Boolean
 */
exportData: function(pAlias, pFieldDivider, pWaitFor, pFile, pTitle, pStatement, pWithFieldIdentifier, pFieldLimiter, pSentenceDivider, pHandleOldFile){},

/**
 * @param {String} pFieldDivider
 * @param {Number} pEscapeStrategy
 * @param {Object} pStatement
 * @param {Array} pOutputFormat
 * @param {String} pSentenceDivider
 * @param {String} pAlias
 * @param {String} pTitle
 * @param {String} pFile
 * @param {Boolean} pWaitFor
 * @param {String} pFieldLimiter
 * @param {Boolean} pWithFieldIdentifier
 * @param {String} pCharset
 * @param {String} pLocale
 * @param {Number} pHandleOldFile
 * @param {String} pEscapeSymbol
 * @type Boolean
 */
fastExportData: function(pFieldDivider, pEscapeStrategy, pStatement, pOutputFormat, pSentenceDivider, pAlias, pTitle, pFile, pWaitFor, pFieldLimiter, pWithFieldIdentifier, pCharset, pLocale, pHandleOldFile, pEscapeSymbol){},

/**
 * @param {Number} pDataType
 * @param {String} pFilename
 * @type Object
 * @throws AditoJDitoException
 */
getData: function(pDataType, pFilename){},

/**
 * @param {Number} pDataType
 * @param {Object} pData
 * @param {String} pFilename
 * @param {Boolean} pAppend
 * @type void
 * @throws AditoJDitoException
 */
storeData: function(pDataType, pData, pFilename, pAppend){},

/**
 * @param {Number} pSelection
 * @type void
 * @throws AditoJDitoException
 */
doAction: function(pSelection){},

/**
 * @param {Number} pSelection
 * @param {String} pTopImageID
 * @param {String} pWindowID
 * @type void
 * @throws AditoJDitoException
 */
doAction: function(pSelection, pTopImageID, pWindowID){},

/**
 * @param {String} pText
 * @type void
 * @throws AditoJDitoException
 */
showMessage: function(pText){},

/**
 * @param {Object} pDetail
 * @param {Number} pMessageTyp
 * @param {String} pText
 * @type Object
 * @throws AditoJDitoException
 */
askQuestion: function(pDetail, pMessageTyp, pText){},

/**
 * @param {String} pFrameName
 * @param {String} pText
 * @type Object
 * @throws AditoJDitoException
 */
askUserQuestion: function(pFrameName, pText){},

/**
 * @param {Array} pTableNames
 * @type void
 * @throws AditoJDitoException
 */
setTablesCanBeDeleted: function(pTableNames){},

/**
 * @param {Array} pTableNames
 * @type void
 * @throws AditoJDitoException
 */
setTablesCanBeCreated: function(pTableNames){},

/**
 * @param {Array} pTableNames
 * @type void
 * @throws AditoJDitoException
 */
setTablesCanBeEdited: function(pTableNames){},

/**
 * @param {Number} pTime
 * @type void
 * @throws AditoJDitoException
 */
sleep: function(pTime){},

/**
 * @type String
 */
getNewUUID: function(){},

/**
 * @param {String} pHTML
 * @type String
 * @throws AditoJDitoException
 */
html2text: function(pHTML){},

/**
 * @param {String} pRTF
 * @type String
 * @throws AditoJDitoException
 */
rtf2text: function(pRTF){},

/**
 * @param {Number} pNumBytes
 * @type String
 * @throws AditoJDitoException
 */
getRandom: function(pNumBytes){},

/**
 * @param {String} pKey
 * @type String
 * @throws AditoJDitoException
 */
translate: function(pKey){},

/**
 * @param {String} pLocale
 * @param {String} pKey
 * @type String
 * @throws AditoJDitoException
 */
translate: function(pLocale, pKey){},

/**
 * @param {Boolean} pSafe
 * @param {String} pKey
 * @type String
 * @throws AditoJDitoException
 */
translate: function(pSafe, pKey){},

/**
 * @param {String} pLocale
 * @param {Boolean} pSafe
 * @param {String} pKey
 * @type String
 * @throws AditoJDitoException
 */
translate: function(pLocale, pSafe, pKey){},

/**
 * @param {Array} pKeys
 * @param {String} pText
 * @type String
 * @throws AditoJDitoException
 */
translate: function(pKeys, pText){},

/**
 * @param {Array} pKeys
 * @param {String} pLocale
 * @param {String} pText
 * @type String
 * @throws AditoJDitoException
 */
translate: function(pKeys, pLocale, pText){},

/**
 * @param {Array} pKeys
 * @param {Boolean} pSafe
 * @param {String} pText
 * @type String
 * @throws AditoJDitoException
 */
translate: function(pKeys, pSafe, pText){},

/**
 * @param {Array} pKeys
 * @param {String} pLocale
 * @param {Boolean} pSafe
 * @param {String} pText
 * @type String
 * @throws AditoJDitoException
 */
translate: function(pKeys, pLocale, pSafe, pText){},

/**
 * @param {String} pComponentName
 * @type void
 * @throws AditoJDitoException
 */
refresh: function(pComponentName){},

/**
 * @param {String} pComponentName
 * @param {String} pImageID
 * @param {String} pWindowID
 * @type void
 * @throws AditoJDitoException
 */
refresh: function(pComponentName, pImageID, pWindowID){},

/**
 * @param {String} pComponentName
 * @param {String} pKey
 * @type void
 * @throws AditoJDitoException
 */
sendKey: function(pComponentName, pKey){},

/**
 * @param {String} pComponentName
 * @param {String} pImageID
 * @param {String} pKey
 * @param {String} pWindowID
 * @type void
 * @throws AditoJDitoException
 */
sendKey: function(pComponentName, pImageID, pKey, pWindowID){},

/**
 * @type Array
 * @throws AditoJDitoException
 */
getCurrentRowData: function(){},

/**
 * @param {String} pImageID
 * @param {String} pWindowID
 * @type Array
 * @throws AditoJDitoException
 */
getCurrentRowData: function(pImageID, pWindowID){},

/**
 * @param {String} pID
 * @param {String} pTableName
 * @type Array
 * @throws AditoJDitoException
 */
getTableData: function(pID, pTableName){},

/**
 * @param {String} pTableName
 * @param {Array} pIDs
 * @type Array
 * @throws AditoJDitoException
 */
getTableData: function(pTableName, pIDs){},

/**
 * @param {String} pTableName
 * @param {Array} pIDs
 * @param {String} pImageID
 * @param {String} pWindowID
 * @type Array
 * @throws AditoJDitoException
 */
getTableData: function(pTableName, pIDs, pImageID, pWindowID){},

/**
 * @param {Boolean} pReloadMissing
 * @param {String} pTableName
 * @param {Array} pUIDs
 * @type void
 * @throws AditoJDitoException
 */
setTableSelection: function(pReloadMissing, pTableName, pUIDs){},

/**
 * @param {Boolean} pReloadMissing
 * @param {String} pTableName
 * @param {String} pImageID
 * @param {Array} pUIDs
 * @param {String} pWindowID
 * @type void
 * @throws AditoJDitoException
 */
setTableSelection: function(pReloadMissing, pTableName, pImageID, pUIDs, pWindowID){},

/**
 * @param {Boolean} pReloadMissing
 * @param {Number} pVAlignment
 * @param {String} pTableName
 * @param {Number} pColumn
 * @param {Array} pUIDs
 * @type void
 * @throws AditoJDitoException
 */
setTableSelection: function(pReloadMissing, pVAlignment, pTableName, pColumn, pUIDs){},

/**
 * @param {Boolean} pReloadMissing
 * @param {Number} pVAlignment
 * @param {String} pTableName
 * @param {String} pImageID
 * @param {Number} pColumn
 * @param {Array} pUIDs
 * @param {String} pWindowID
 * @type void
 * @throws AditoJDitoException
 */
setTableSelection: function(pReloadMissing, pVAlignment, pTableName, pImageID, pColumn, pUIDs, pWindowID){},

/**
 * @param {Boolean} pOperator
 * @param {String} pTableName
 * @param {Array} pKeyWords
 * @type void
 * @throws AditoJDitoException
 */
setTableSelectionByKeywords: function(pOperator, pTableName, pKeyWords){},

/**
 * @param {Array} pKeywords
 * @param {Boolean} pOperator
 * @param {String} pTableName
 * @param {String} pImageID
 * @param {String} pWindowID
 * @type void
 * @throws AditoJDitoException
 */
setTableSelectionByKeywords: function(pKeywords, pOperator, pTableName, pImageID, pWindowID){},

/**
 * @param {Number} pVAlignment
 * @param {Boolean} pOperator
 * @param {String} pTableName
 * @param {Number} pColumn
 * @param {Array} pKeyWords
 * @type void
 * @throws AditoJDitoException
 */
setTableSelectionByKeywords: function(pVAlignment, pOperator, pTableName, pColumn, pKeyWords){},

/**
 * @param {Array} pKeywords
 * @param {Number} pVAlignment
 * @param {Boolean} pOperator
 * @param {String} pTableName
 * @param {String} pImageID
 * @param {Number} pColumn
 * @param {String} pWindowID
 * @type void
 * @throws AditoJDitoException
 */
setTableSelectionByKeywords: function(pKeywords, pVAlignment, pOperator, pTableName, pImageID, pColumn, pWindowID){},

/**
 * @param {Number} pVAlignment
 * @param {String} pTableName
 * @param {Number} pColRelative
 * @param {Number} pRowRelative
 * @type void
 * @throws AditoJDitoException
 */
setTableSelectionRelative: function(pVAlignment, pTableName, pColRelative, pRowRelative){},

/**
 * @param {Number} pVAlignment
 * @param {String} pTableName
 * @param {String} pImageID
 * @param {Number} pColRelative
 * @param {Number} pRowRelative
 * @param {String} pWindowID
 * @type void
 * @throws AditoJDitoException
 */
setTableSelectionRelative: function(pVAlignment, pTableName, pImageID, pColRelative, pRowRelative, pWindowID){},

/**
 * @param {String} pTableName
 * @param {Boolean} pVisibility
 * @param {Number} pColumnIndex
 * @type void
 * @throws AditoJDitoException
 */
setTableColumnVisibility: function(pTableName, pVisibility, pColumnIndex){},

/**
 * @param {String} pTableName
 * @param {String} pImageID
 * @param {Boolean} pVisibility
 * @param {Number} pColumnIndex
 * @param {String} pWindowID
 * @type void
 * @throws AditoJDitoException
 */
setTableColumnVisibility: function(pTableName, pImageID, pVisibility, pColumnIndex, pWindowID){},

/**
 * @param {String} pTableName
 * @param {String} pImageID
 * @param {Number} pAttribute
 * @param {String} pWindowID
 * @type Array
 * @throws AditoJDitoException
 */
getTableData: function(pTableName, pImageID, pAttribute, pWindowID){},

/**
 * @param {String} pTableName
 * @param {Number} pAttribute
 * @type Array
 * @throws AditoJDitoException
 */
getTableData: function(pTableName, pAttribute){},

/**
 * @param {String} pTableName
 * @type String
 * @throws AditoJDitoException
 */
addTableRow: function(pTableName){},

/**
 * @param {String} pTableName
 * @param {String} pImageID
 * @param {String} pWindowID
 * @type String
 * @throws AditoJDitoException
 */
addTableRow: function(pTableName, pImageID, pWindowID){},

/**
 * @param {String} pTableName
 * @param {Array} pUIDs
 * @type void
 * @throws AditoJDitoException
 */
deleteTableRows: function(pTableName, pUIDs){},

/**
 * @param {String} pTableName
 * @param {String} pImageID
 * @param {Array} pUIDs
 * @param {String} pWindowID
 * @type void
 * @throws AditoJDitoException
 */
deleteTableRows: function(pTableName, pImageID, pUIDs, pWindowID){},

/**
 * @param {String} pTableName
 * @param {String} pViewValue
 * @param {Number} pColumn
 * @param {String} pIDValue
 * @param {String} pUID
 * @type void
 * @throws AditoJDitoException
 */
updateTableCell: function(pTableName, pViewValue, pColumn, pIDValue, pUID){},

/**
 * @param {String} pTableName
 * @param {String} pViewValue
 * @param {String} pImageID
 * @param {Number} pColumn
 * @param {String} pIDValue
 * @param {String} pUID
 * @param {String} pWindowID
 * @type void
 * @throws AditoJDitoException
 */
updateTableCell: function(pTableName, pViewValue, pImageID, pColumn, pIDValue, pUID, pWindowID){},

/**
 * @param {String} pTableName
 * @param {Array} pUIDs
 * @type void
 * @throws AditoJDitoException
 */
undoTableEdit: function(pTableName, pUIDs){},

/**
 * @param {String} pTableName
 * @param {String} pImageID
 * @param {Array} pUIDs
 * @param {String} pWindowID
 * @type void
 * @throws AditoJDitoException
 */
undoTableEdit: function(pTableName, pImageID, pUIDs, pWindowID){},

/**
 * @param {String} pTableName
 * @type void
 * @throws AditoJDitoException
 */
saveTableEdit: function(pTableName){},

/**
 * @param {String} pTableName
 * @param {String} pImageID
 * @param {String} pWindowID
 * @type void
 * @throws AditoJDitoException
 */
saveTableEdit: function(pTableName, pImageID, pWindowID){},

/**
 * @param {String} pRegisterTabName
 * @type void
 * @throws AditoJDitoException
 */
showRegisterTab: function(pRegisterTabName){},

/**
 * @param {String} pImageID
 * @param {String} pWindowID
 * @param {String} pRegisterTabName
 * @type void
 * @throws AditoJDitoException
 */
showRegisterTab: function(pImageID, pWindowID, pRegisterTabName){},

/**
 * @param {Number} pColumnCount
 * @type Object
 * @throws AditoJDitoException
 */
createEmptyTable: function(pColumnCount){},

/**
 * @param {String} pTitle
 * @param {String} pMessage
 * @param {Number} pType
 * @type void
 */
systemTrayShow: function(pTitle, pMessage, pType){},

/**
 * @type void
 */
systemTrayRestore: function(){},

/**
 * @param {String} pFieldLimit
 * @param {String} pLineDelim
 * @param {String} pInput
 * @param {String} pFieldDelim
 * @type Array
 * @throws AditoJDitoException
 */
parseCSV: function(pFieldLimit, pLineDelim, pInput, pFieldDelim){},

/**
 * @param {String} pFieldLimit
 * @param {String} pLineDelim
 * @param {Array} pElements
 * @param {String} pFieldDelim
 * @type String
 * @throws AditoJDitoException
 */
toCSV: function(pFieldLimit, pLineDelim, pElements, pFieldDelim){},

/**
 * @type String
 */
getCurrentAlias: function(){},

/**
 * @type Array
 * @throws AditoJDitoException
 */
getTopImages: function(){},

/**
 * @param {String} pKey
 * @type String
 * @throws AditoJDitoException
 */
getVMProperty: function(pKey){},

/**
 * @param {String} pText
 * @type String
 * @throws AditoJDitoException
 */
encodeBase64String: function(pText){},

/**
 * @param {String} pCharset
 * @param {String} pText
 * @type String
 * @throws AditoJDitoException
 */
encodeBase64String: function(pCharset, pText){},

/**
 * @param {String} pText
 * @type String
 * @throws AditoJDitoException
 */
decodeBase64String: function(pText){},

/**
 * @param {String} pCharset
 * @param {String} pText
 * @type String
 * @throws AditoJDitoException
 */
decodeBase64String: function(pCharset, pText){},

/**
 * @param {Object} pReplacements
 * @param {String} pText
 * @type String
 * @throws AditoJDitoException
 */
replaceAll: function(pReplacements, pText){},

/**
 * @param {String} pRegex
 * @param {String} pText
 * @type Array
 * @throws AditoJDitoException
 */
split: function(pRegex, pText){},

/**
 * @param {String} pText
 * @type void
 */
print: function(pText){}

};


tools = {

/**
 * @type String 
 */
TITLE: undefined,

/**
 * @type String 
 */
DESCRIPTION: undefined,

/**
 * @type String 
 */
PASSWORD: undefined,

/**
 * @type String 
 */
ICON: undefined,

/**
 * @type String 
 */
PARAMS: undefined,

/**
 * @type String 
 */
GROUPS: undefined,

/**
 * @type String 
 */
ROLES: undefined,

/**
 * @type String 
 */
ROLES_NOSELF: undefined,

/**
 * @type String 
 */
MODELS: undefined,

/**
 * @type String 
 */
MYROLE: undefined,

/**
 * @type String 
 */
SELECTION_POSTFIX: undefined,

/**
 * @type String 
 */
SELECTION_PREFIX: undefined,

/**
 * @type String 
 */
SELECTION_BOTH: undefined,

/**
 * @type String 
 */
SELECTION_NEITHER: undefined,

/**
 * @type String 
 */
SELECTION_NULL: undefined,

/**
 * @type String 
 */
ROLE_INTERNAL: undefined,

/**
 * @type String 
 */
ROLE_USER: undefined,

/**
 * @type String 
 */
ROLE_PROJECT: undefined,

/**
 * @type Array
 * @throws AditoJDitoException
 */
getStoredUsers: function(){},

/**
 * @type Object
 * @throws AditoJDitoException
 */
getAllGroups: function(){},

/**
 * @param {Array} pRoleTypes
 * @type Object
 * @throws AditoJDitoException
 */
getAllRoles: function(pRoleTypes){},

/**
 * @param {String} pTitle
 * @param {String} pName
 * @type void
 * @throws AditoJDitoException
 */
addRole: function(pTitle, pName){},

/**
 * @param {String} pTitle
 * @param {String} pName
 * @type void
 * @throws AditoJDitoException
 */
updateRole: function(pTitle, pName){},

/**
 * @param {String} pName
 * @type void
 * @throws AditoJDitoException
 */
deleteRole: function(pName){},

/**
 * @param {String} pRoleName
 * @param {Object} pRoles
 * @type Boolean
 * @throws AditoJDitoException
 */
containsRole: function(pRoleName, pRoles){},

/**
 * @param {Array} pRoleNames
 * @param {Object} pRoles
 * @type Boolean
 * @throws AditoJDitoException
 */
containsAnyRole: function(pRoleNames, pRoles){},

/**
 * @param {String} pRoleName
 * @param {String} pUserLogin
 * @type Boolean
 * @throws AditoJDitoException
 */
hasRole: function(pRoleName, pUserLogin){},

/**
 * @param {Array} pRoleNames
 * @param {String} pUserLogin
 * @type Boolean
 * @throws AditoJDitoException
 */
hasAnyRole: function(pRoleNames, pUserLogin){},

/**
 * @param {String} pUserLogin
 * @type Array
 * @throws AditoJDitoException
 */
getRoles: function(pUserLogin){},

/**
 * @param {String} pRoleName
 * @type Array
 * @throws AditoJDitoException
 */
getUsersWithRole: function(pRoleName){},

/**
 * @param {Array} pRoleNames
 * @type Array
 * @throws AditoJDitoException
 */
getUsersWithAnyRole: function(pRoleNames){},

/**
 * @param {String} pTitle
 * @type Object
 * @throws AditoJDitoException
 */
getUser: function(pTitle){},

/**
 * @param {Object} pTitle
 * @type Array
 * @throws AditoJDitoException
 */
getUsers: function(pTitle){},

/**
 * @param {Object} pTitle
 * @type Boolean
 * @throws AditoJDitoException
 */
existUsers: function(pTitle){},

/**
 * @param {Object} pLogin
 * @type Array
 * @throws AditoJDitoException
 */
resolveUsers: function(pLogin){},

/**
 * @param {String} pLogin
 * @type String
 * @throws AditoJDitoException
 */
resolveUser: function(pLogin){},

/**
 * @param {String} pTitle
 * @type void
 * @throws AditoJDitoException
 */
deleteUser: function(pTitle){},

/**
 * @param {Object} pUser
 * @type void
 * @throws AditoJDitoException
 */
updateUser: function(pUser){},

/**
 * @param {Object} pUser
 * @type void
 * @throws AditoJDitoException
 */
insertUser: function(pUser){},

/**
 * @param {ExtendedRoleManager} pRoleManager
 * @param {IUser} pUser
 * @type Array
 */
_getAssignableRoles: function(pRoleManager, pUser){},

/**
 * @type String
 */
getReadableID: function(){}

};


calendar = {

/**
 * @type Number 
 */
MODE_INSERT: undefined,

/**
 * @type Number 
 */
MODE_UPDATE: undefined,

/**
 * @type Number 
 */
VEVENT: undefined,

/**
 * @type Number 
 */
VTODO: undefined,

/**
 * @type Number 
 */
VFREEBUSY: undefined,

/**
 * @type Number 
 */
BACKEND_NONE: undefined,

/**
 * @type Number 
 */
BACKEND_DB: undefined,

/**
 * @type Number 
 */
BACKEND_EXCHANGE: undefined,

/**
 * @type Number 
 */
BACKEND_DOMINO: undefined,

/**
 * @type String 
 */
TYPE: undefined,

/**
 * @type String 
 */
ID: undefined,

/**
 * @type String 
 */
SUMMARY: undefined,

/**
 * @type String 
 */
LOCATION: undefined,

/**
 * @type String 
 */
DESCRIPTION: undefined,

/**
 * @type String 
 */
DTSTART: undefined,

/**
 * @type String 
 */
DTEND: undefined,

/**
 * @type String 
 */
USER: undefined,

/**
 * @type String 
 */
STATUS: undefined,

/**
 * @type String 
 */
HASREMINDER: undefined,

/**
 * @type String 
 */
REMINDER: undefined,

/**
 * @type String 
 */
REMINDER_DATE: undefined,

/**
 * @type String 
 */
DUE: undefined,

/**
 * @type String 
 */
LINKS: undefined,

/**
 * @type String 
 */
PERCENT: undefined,

/**
 * @type String 
 */
PRIORITY: undefined,

/**
 * @type String 
 */
CLASSIFICATION: undefined,

/**
 * @type String 
 */
AFFECTEDUSERS: undefined,

/**
 * @type String 
 */
ORGANIZER: undefined,

/**
 * @type String 
 */
CREATED: undefined,

/**
 * @type String 
 */
LASTMODIFIED: undefined,

/**
 * @type String 
 */
CATEGORIES: undefined,

/**
 * @type String 
 */
RECURRENCEID: undefined,

/**
 * @type String 
 */
REMINDER_ACTION: undefined,

/**
 * @type String 
 */
REMINDER_DURATION: undefined,

/**
 * @type String 
 */
REMINDER_RELATED: undefined,

/**
 * @type String 
 */
REMINDER_ABSOLUT: undefined,

/**
 * @type String 
 */
DURATION: undefined,

/**
 * @type String 
 */
REMINDER_LAST: undefined,

/**
 * @type String 
 */
TRANSPARENCY: undefined,

/**
 * @type String 
 */
DTSTAMP: undefined,

/**
 * @type String 
 */
COMMENT: undefined,

/**
 * @type String 
 */
FREEBUSY: undefined,

/**
 * @type String 
 */
RRULE: undefined,

/**
 * @type String 
 */
RDATE: undefined,

/**
 * @type String 
 */
EXRULE: undefined,

/**
 * @type String 
 */
EXDATE: undefined,

/**
 * @type String 
 */
LINK_ALIAS: undefined,

/**
 * @type String 
 */
LINK_TABLE: undefined,

/**
 * @type String 
 */
LINK_IDCOLUMN: undefined,

/**
 * @type String 
 */
LINK_DBID: undefined,

/**
 * @type String 
 */
LINK_FRAME: undefined,

/**
 * @type String 
 */
LINK_TITLE: undefined,

/**
 * @type Number 
 */
SHOW_DATE: undefined,

/**
 * @type Number 
 */
SHOW_TASK: undefined,

/**
 * @type Number 
 */
SHOW_CAL: undefined,

/**
 * @type Number 
 */
SHOW_ALL: undefined,

/**
 * @type Number 
 */
VIEWMODE_DAYS: undefined,

/**
 * @type Number 
 */
VIEWMODE_WEEKS: undefined,

/**
 * @type Number 
 */
VIEWMODE_WORKWEEK: undefined,

/**
 * @type Number 
 */
VIEWMODE_SCHEDULE: undefined,

/**
 * @type Number 
 */
VIEWMODE_DEFAULT: undefined,

/**
 * @type Number 
 */
RIGHT_READ: undefined,

/**
 * @type Number 
 */
RIGHT_WRITE: undefined,

/**
 * @type String 
 */
CONDITION_COUNT: undefined,

/**
 * @type String 
 */
CONDITION_USER: undefined,

/**
 * @type String 
 */
CONDITION_ENDTIME: undefined,

/**
 * @type String 
 */
CONDITION_STARTTIME: undefined,

/**
 * @type String 
 */
CONDITION_UID: undefined,

/**
 * @type String 
 */
CONDITION_STATUS: undefined,

/**
 * @type String 
 */
CONDITION_TYPE: undefined,

/**
 * @type String 
 */
CONDITION_LASTMODIFIED: undefined,

/**
 * @type Number 
 */
GROUP_NONE: undefined,

/**
 * @type Number 
 */
GROUP_SINGLE: undefined,

/**
 * @type Number 
 */
GROUP_MULTI: undefined,

/**
 * @type String 
 */
STATUS_TENTATIVE: undefined,

/**
 * @type String 
 */
STATUS_CONFIRMED: undefined,

/**
 * @type String 
 */
STATUS_CANCELLED: undefined,

/**
 * @type String 
 */
STATUS_NEEDSACTION: undefined,

/**
 * @type String 
 */
STATUS_COMPLETED: undefined,

/**
 * @type String 
 */
STATUS_INPROCESS: undefined,

/**
 * @type String 
 */
CLASSIFICATION_PUBLIC: undefined,

/**
 * @type String 
 */
CLASSIFICATION_PRIVATE: undefined,

/**
 * @type String 
 */
TRANSPARENCY_TRANSPARENT: undefined,

/**
 * @type String 
 */
TRANSPARENCY_OPAQUE: undefined,

/**
 * @type String 
 */
ELEM_CATEGORIES_EVENT: undefined,

/**
 * @type String 
 */
ELEM_CATEGORIES_TODO: undefined,

/**
 * @type Number 
 */
SORTSTRATEGY_NONE: undefined,

/**
 * @type Number 
 */
SORTSTRATEGY_NATURAL: undefined,

/**
 * @type Number 
 */
SORTSTRATEGY_LASTWORD: undefined,

/**
 * @type Number 
 */
SORTSTRATEGY_AFTERDOT: undefined,

/**
 * @type Number
 */
getBackendType: function(){},

/**
 * @param {String} pProcess
 * @type void
 * @throws AditoJDitoException
 */
setReminderProcess: function(pProcess){},

/**
 * @param {String} pProcess
 * @type void
 * @throws AditoJDitoException
 */
setInsertProcess: function(pProcess){},

/**
 * @param {String} pProcess
 * @type void
 * @throws AditoJDitoException
 */
setUpdateProcess: function(pProcess){},

/**
 * @param {String} pProcess
 * @type void
 * @throws AditoJDitoException
 */
setDeleteProcess: function(pProcess){},

/**
 * @param {Boolean} pNewWindow
 * @type String
 * @throws AditoJDitoException
 */
open: function(pNewWindow){},

/**
 * @param {Boolean} pNewWindow
 * @param {Number} pCalendarMode
 * @type String
 * @throws AditoJDitoException
 */
open: function(pNewWindow, pCalendarMode){},

/**
 * @param {Boolean} pNewWindow
 * @param {Number} pCalendarMode
 * @param {Number} pViewMode
 * @type String
 * @throws AditoJDitoException
 */
open: function(pNewWindow, pCalendarMode, pViewMode){},

/**
 * @param {Object} pUsers
 * @param {Boolean} pNewWindow
 * @param {Number} pCalendarMode
 * @param {Number} pViewMode
 * @type String
 * @throws AditoJDitoException
 */
open: function(pUsers, pNewWindow, pCalendarMode, pViewMode){},

/**
 * @param {Object} pUsers
 * @param {Boolean} pNewWindow
 * @param {Number} pCalendarMode
 * @param {Number} pViewMode
 * @param {Array} pDays
 * @type String
 * @throws AditoJDitoException
 */
open: function(pUsers, pNewWindow, pCalendarMode, pViewMode, pDays){},

/**
 * @param {Number} pWindowMode
 * @type String
 * @throws AditoJDitoException
 */
open: function(pWindowMode){},

/**
 * @param {Number} pCalendarMode
 * @param {Number} pWindowMode
 * @type String
 * @throws AditoJDitoException
 */
open: function(pCalendarMode, pWindowMode){},

/**
 * @param {Number} pCalendarMode
 * @param {Number} pViewMode
 * @param {Number} pWindowMode
 * @type String
 * @throws AditoJDitoException
 */
open: function(pCalendarMode, pViewMode, pWindowMode){},

/**
 * @param {Object} pUsers
 * @param {Number} pCalendarMode
 * @param {Number} pViewMode
 * @param {Number} pWindowMode
 * @type String
 * @throws AditoJDitoException
 */
open: function(pUsers, pCalendarMode, pViewMode, pWindowMode){},

/**
 * @param {Object} pUsers
 * @param {Number} pCalendarMode
 * @param {Number} pViewMode
 * @param {Number} pWindowMode
 * @param {Array} pDays
 * @type String
 * @throws AditoJDitoException
 */
open: function(pUsers, pCalendarMode, pViewMode, pWindowMode, pDays){},

/**
 * @type void
 * @throws AditoJDitoException
 */
clearCache: function(){},

/**
 * @param {Boolean} pNewWindow
 * @param {Object} pEntry
 * @type void
 * @throws AditoJDitoException
 */
openEntry: function(pNewWindow, pEntry){},

/**
 * @param {Boolean} pNewWindow
 * @param {Object} pEntry
 * @param {String} pReccurrenceID
 * @type void
 * @throws AditoJDitoException
 */
openEntry: function(pNewWindow, pEntry, pReccurrenceID){},

/**
 * @param {Boolean} pNewWindow
 * @param {Object} pEntry
 * @type void
 * @throws AditoJDitoException
 */
editEntry: function(pNewWindow, pEntry){},

/**
 * @param {Boolean} pNewWindow
 * @param {Object} pEntry
 * @param {String} pReccurrenceID
 * @type void
 * @throws AditoJDitoException
 */
editEntry: function(pNewWindow, pEntry, pReccurrenceID){},

/**
 * @param {String} pCalendarEntryUID
 * @param {Number} pWindowMode
 * @param {Boolean} pLinked
 * @param {Object} pLinks
 * @type void
 * @throws AditoJDitoException
 */
openLinks: function(pCalendarEntryUID, pWindowMode, pLinked, pLinks){},

/**
 * @param {Number} pRights
 * @type Array
 * @throws AditoJDitoException
 */
getFullCalendarUsers: function(pRights){},

/**
 * @param {Number} pRights
 * @type Array
 * @throws AditoJDitoException
 */
getDisplayCalendarUsers: function(pRights){},

/**
 * @type Array
 * @throws AditoJDitoException
 */
getCalendarUser: function(){},

/**
 * @param {Object} pCalendarUser
 * @param {Number} pRights
 * @type void
 * @throws AditoJDitoException
 */
setCalendarUser: function(pCalendarUser, pRights){},

/**
 * @param {Object} pCalendarUser
 * @param {Number} pRights
 * @param {Boolean} pRemoveInactive
 * @type void
 * @throws AditoJDitoException
 */
setCalendarUser: function(pCalendarUser, pRights, pRemoveInactive){},

/**
 * @param {Number} pSortStrategy
 * @param {Object} pCalendarUser
 * @param {Number} pRights
 * @param {Boolean} pRemoveInactive
 * @type void
 * @throws AditoJDitoException
 */
setCalendarUser: function(pSortStrategy, pCalendarUser, pRights, pRemoveInactive){},

/**
 * @type void
 * @throws AditoJDitoException
 */
resetCalendarUser: function(){},

/**
 * @param {String} pTitle
 * @type String
 * @throws AditoJDitoException
 */
getCalendarUser: function(pTitle){},

/**
 * @param {Object} pTitle
 * @type Array
 * @throws AditoJDitoException
 */
getCalendarUsers: function(pTitle){},

/**
 * @type Object
 */
getElementPrefs: function(){},

/**
 * @param {String} pRule
 * @type Object
 * @throws AditoJDitoException
 */
getRuleAsMap: function(pRule){},

/**
 * @param {String} pUID
 * @type Array
 * @throws AditoJDitoException
 */
getEntry: function(pUID){},

/**
 * @param {Number} pIntervalStart
 * @param {String} pID
 * @param {Number} pIntervalEnd
 * @type Array
 * @throws AditoJDitoException
 */
getExpandendEntry: function(pIntervalStart, pID, pIntervalEnd){},

/**
 * @param {Number} pIntervalStart
 * @param {String} pID
 * @param {Number} pIntervalEnd
 * @type Array
 * @throws AditoJDitoException
 */
getExpandedEntry: function(pIntervalStart, pID, pIntervalEnd){},

/**
 * @param {Number} pIntervalStart
 * @param {NativeArray} pConditions
 * @param {Number} pIntervalEnd
 * @type Array
 * @throws AditoJDitoException
 */
getExpandedEntries: function(pIntervalStart, pConditions, pIntervalEnd){},

/**
 * @param {NativeArray} pConditions
 * @type Array
 * @throws AditoJDitoException
 */
getEntries: function(pConditions){},

/**
 * @param {Object} pEntry
 * @type Array
 * @throws AditoJDitoException
 */
insert: function(pEntry){},

/**
 * @param {Number} pGroupType
 * @param {Object} pEntry
 * @type Array
 * @throws AditoJDitoException
 */
insert: function(pGroupType, pEntry){},

/**
 * @param {Object} pElement
 * @type void
 * @throws AditoJDitoException
 */
update: function(pElement){},

/**
 * @param {Object} pEntry
 * @type void
 * @throws AditoJDitoException
 */
updateEntry: function(pEntry){},

/**
 * @param {Object} pEntry
 * @type void
 * @throws AditoJDitoException
 */
remove: function(pEntry){},

/**
 * @param {String} pReccurenceID
 * @param {Object} pEntry
 * @type void
 * @throws AditoJDitoException
 */
removeEntry: function(pReccurenceID, pEntry){},

/**
 * @param {Object} pEntry
 * @type void
 * @throws AditoJDitoException
 */
removeEntry: function(pEntry){},

/**
 * @param {String} pICalText
 * @param {String} pDefaultTimeZone
 * @type void
 * @throws AditoJDitoException
 */
importICS: function(pICalText, pDefaultTimeZone){},

/**
 * @type Array
 * @throws AditoJDitoException
 */
getAvailableTimeZones: function(){},

/**
 * @type String
 */
getReadableID: function(){}

};


