
a = {

/**
 * @type String
 */
ALIAS_NAME: undefined,
/**
 * @type String
 */
ALIAS_DATASOURCETYPE: undefined,
/**
 * @type String
 */
ALIAS_PROPERTIES: undefined,

/**
 * @type Number
 */
FRAMEMODE_SHOW: undefined,
/**
 * @type Number
 */
FRAMEMODE_SEARCH: undefined,
/**
 * @type Number
 */
FRAMEMODE_NEW: undefined,
/**
 * @type Number
 */
FRAMEMODE_EDIT: undefined,
/**
 * @type Number
 */
FRAMEMODE_TABLE: undefined,
/**
 * @type Number
 */
FRAMEMODE_TABLE_SELECTION: undefined,

/**
 * @type Number
 */
EXPORT_APPEND: undefined,
/**
 * @type Number
 */
EXPORT_ABORT: undefined,
/**
 * @type Number
 */
EXPORT_OVERWRITE: undefined,

/**
 * @type Object
 */
SQL_COMPLETE: undefined,
/**
 * @type Number
 */
SQL_ROW: undefined,
/**
 * @type Number
 */
SQL_COLUMN: undefined,
/**
 * @type String
 */
EMPTY_TABLE_SQL: undefined,

/**
 * @type Number
 */
QUESTION_OK: undefined,
/**
 * @type Number
 */
QUESTION_YESNO: undefined,
/**
 * @type Number
 */
QUESTION_YESNOCANCEL: undefined,
/**
 * @type Number
 */
QUESTION_COMBOBOX: undefined,
/**
 * @type Number
 */
QUESTION_EDIT: undefined,
/**
 * @type Number
 */
QUESTION_FILECHOOSER: undefined,
/**
 * @type Number
 */
QUESTION_DIRECTORYCHOOSER: undefined,
/**
 * @type Number
 */
QUESTION_USER: undefined,

/**
 * @type Number
 */
REPORT_OPEN: undefined,
/**
 * @type Number
 */
REPORT_PRINT: undefined,
/**
 * @type Number
 */
REPORT_EXPORT: undefined,

/**
 * @type Number
 */
REPORT_EXPORT_CSV: undefined,
/**
 * @type Number
 */
REPORT_EXPORT_HTML: undefined,
/**
 * @type Number
 */
REPORT_EXPORT_PDF: undefined,
/**
 * @type Number
 */
REPORT_EXPORT_RTF: undefined,
/**
 * @type Number
 */
REPORT_EXPORT_MSEXCEL: undefined,
/**
 * @type Number
 */
REPORT_EXPORT_XLS: undefined,
/**
 * @type Number
 */
REPORT_EXPORT_XML: undefined,
/**
 * @type Number
 */
REPORT_EXPORT_SVG: undefined,
/**
 * @type Number
 */
REPORT_EXPORT_PS: undefined,
/**
 * @type Number
 */
REPORT_EXPORT_PS2: undefined,
/**
 * @type Number
 */
REPORT_EXPORT_PS3: undefined,
/**
 * @type Number
 */
REPORT_EXPORT_TXT: undefined,
/**
 * @type Number
 */
REPORT_EXPORT_BMP: undefined,
/**
 * @type Number
 */
REPORT_EXPORT_PNG: undefined,
/**
 * @type Number
 */
REPORT_EXPORT_JPG: undefined,
/**
 * @type Number
 */
REPORT_EXPORT_GIF: undefined,

/**
 * @type Number
 */
CLIENTCMD_OPENFILE: undefined,
/**
 * @type Number
 */
CLIENTCMD_OPENURL: undefined,
/**
 * @type Number
 */
CLIENTCMD_EXECUTE: undefined,
/**
 * @type Number
 */
CLIENTCMD_EXECUTE_WAIT: undefined,
/**
 * @type Number
 */
CLIENTCMD_SLEEP: undefined,
/**
 * @type Number
 */
CLIENTCMD_BEEP: undefined,
/**
 * @type Number
 */
CLIENTCMD_MESSAGE: undefined,
/**
 * @type Number
 */
CLIENTCMD_STOREDATA: undefined,
/**
 * @type Number
 */
CLIENTCMD_GETDATA: undefined,
/**
 * @type Number
 */
CLIENTCMD_TOCLIPBOARD: undefined,
/**
 * @type Number
 */
CLIENTCMD_FROMCLIPBOARD: undefined,
/**
 * @type Number
 */
CLIENTCMD_GETPROPERTY: undefined,
/**
 * @type Number
 */
CLIENTCMD_FILEREADABLE: undefined,
/**
 * @type Number
 */
CLIENTCMD_FILEWRITEABLE: undefined,
/**
 * @type Number
 */
CLIENTCMD_RUNPLUGIN: undefined,
/**
 * @type Number
 */
CLIENTCMD_FILEIO_CANREAD: undefined,
/**
 * @type Number
 */
CLIENTCMD_FILEIO_CANWRITE: undefined,
/**
 * @type Number
 */
CLIENTCMD_FILEIO_DELETE: undefined,
/**
 * @type Number
 */
CLIENTCMD_FILEIO_EXISTS: undefined,
/**
 * @type Number
 */
CLIENTCMD_FILEIO_GETABSOLUTE: undefined,
/**
 * @type Number
 */
CLIENTCMD_FILEIO_GETLENGTH: undefined,
/**
 * @type Number
 */
CLIENTCMD_FILEIO_GETNAME: undefined,
/**
 * @type Number
 */
CLIENTCMD_FILEIO_GETPARENT: undefined,
/**
 * @type Number
 */
CLIENTCMD_FILEIO_ISDIRECTORY: undefined,
/**
 * @type Number
 */
CLIENTCMD_FILEIO_ISFILE: undefined,
/**
 * @type Number
 */
CLIENTCMD_FILEIO_ISHIDDEN: undefined,
/**
 * @type Number
 */
CLIENTCMD_FILEIO_LASTMODIFIED: undefined,
/**
 * @type Number
 */
CLIENTCMD_FILEIO_MKDIR: undefined,
/**
 * @type Number
 */
CLIENTCMD_FILEIO_RENAME: undefined,
/**
 * @type Number
 */
CLIENTCMD_FILEIO_SETREADONLY: undefined,
/**
 * @type Number
 */
CLIENTCMD_FILEIO_LISTFILES: undefined,
/**
 * @type Number
 */
DATA_TEXT: undefined,
/**
 * @type Number
 */
DATA_BINARY: undefined,
/**
 * @type Number
 */
CLIENTCMD_DATA_TEXT: undefined,
/**
 * @type Number
 */
CLIENTCMD_DATA_BINARY: undefined,

/**
 * @type Number
 */
ONE_SECOND: undefined,
/**
 * @type Number
 */
ONE_MINUTE: undefined,
/**
 * @type Number
 */
ONE_HOUR: undefined,
/**
 * @type Number
 */
ONE_DAY: undefined,
/**
 * @type Number
 */
ONE_WEEK: undefined,

/**
 * @type Number
 */
DBTYPE_INTERBASE7: undefined,
/**
 * @type Number
 */
DBTYPE_ORACLE10_THIN: undefined,
/**
 * @type Number
 */
DBTYPE_ORACLE10_OCI: undefined,
/**
 * @type Number
 */
DBTYPE_ORACLE10_CLUSTER: undefined,
/**
 * @type Number
 */
DBTYPE_SQLSERVER2000: undefined,
/**
 * @type Number
 */
DBTYPE_MYSQL4: undefined,
/**
 * @type Number
 */
DBTYPE_SYBASE125: undefined,
/**
 * @type Number
 */
DBTYPE_DERBY10: undefined,
/**
 * @type Number
 */
DBTYPE_POSTGRESQL8: undefined,

/**
 * @type Number
 */
DATAMODEL_KIND_FRAME: undefined,
/**
 * @type Number
 */
DATAMODEL_KIND_ALIAS: undefined,
/**
 * @type Number
 */
DATAMODEL_KIND_PROCESS: undefined,
/**
 * @type Number
 */
DATAMODEL_KIND_REPORT: undefined,

/**
 * @type Number
 */
TIMERTYPE_CLIENT_RUN: undefined,
/**
 * @type Number
 */
TIMERTYPE_SERVER: undefined,
/**
 * @type Number
 */
TIMERTYPE_SERVER_RUN: undefined,
/**
 * @type Number
 */
TIMERTYPE_CLUSTER: undefined,

/**
 * @type Number
 */
IMAGE_TYPE_FRAME: undefined,
/**
 * @type Number
 */
IMAGE_TYPE_MAIL: undefined,
/**
 * @type Number
 */
IMAGE_TYPE_CALENDAR: undefined,
/**
 * @type Number
 */
IMAGE_TYPE_REPORT: undefined,

/**
 * @type Number
 */
SYSTEMTRAY_NONE: undefined,
/**
 * @type Number
 */
SYSTEMTRAY_INFO: undefined,
/**
 * @type Number
 */
SYSTEMTRAY_WARNING: undefined,
/**
 * @type Number
 */
SYSTEMTRAY_ERROR: undefined,

/**
 * @type Number
 */
WINDOW_CURRENT: undefined,
/**
 * @type Number
 */
WINDOW_NEW: undefined,

/**
 * @type Number
 */
ESCAPEMODE_ESCAPE: undefined,
/**
 * @type Number
 */
ESCAPEMODE_DOUBLE: undefined,
/**
 * @type Number
 */
ESCAPEMODE_CHANGE: undefined,
/**
 * @type Number
 */
ESCAPEMODE_NOTHING: undefined,

/**
 * @type Number
 */
WINDOWPOSITION_DEFAULT: undefined,
/**
 * @type Number
 */
WINDOWPOSITION_CENTERONSCREEN: undefined,
/**
 * @type Number
 */
WINDOWPOSITION_CENTERONWINDOW: undefined,

/**
 * @type Number
 */
CONDITION_STATIC: undefined,
/**
 * @type Number
 */
CONDITION_DESIGNER: undefined,
/**
 * @type Number
 */
CONDITION_SEARCHMASK: undefined,
/**
 * @type Number
 */
CONDITION_LINK: undefined,
/**
 * @type Number
 */
CONDITION_EXTRA: undefined,

/**
 * @type String
 */
OPERATOR_EQUAL: undefined,
/**
 * @type String
 */
OPERATOR_NOT_EQUAL: undefined,
/**
 * @type String
 */
OPERATOR_GREATER: undefined,
/**
 * @type String
 */
OPERATOR_LESS: undefined,
/**
 * @type String
 */
OPERATOR_LESS_OR_EQUAL: undefined,
/**
 * @type String
 */
OPERATOR_GREATER_OR_EQUAL: undefined,
/**
 * @type String
 */
OPERATOR_LIKE: undefined,
/**
 * @type String
 */
OPERATOR_NOT_LIKE: undefined,
/**
 * @type String
 */
OPERATOR_NOT_NULL: undefined,
/**
 * @type String
 */
OPERATOR_NULL: undefined,
/**
 * @type String
 */
OPERATOR_NOT_IN: undefined,
/**
 * @type String
 */
OPERATOR_IN: undefined,

/**
 * @type Number
 */
INSERTED: undefined,
/**
 * @type Number
 */
UPDATED: undefined,
/**
 * @type Number
 */
DELETED: undefined,
/**
 * @type Number
 */
ALL: undefined,

/**
 * @type Boolean
 */
SELECTION_OR: undefined,
/**
 * @type Boolean
 */
SELECTION_AND: undefined,






/**
 * @param {String} result
 * @type void
 */
returndynamic: function(result){},

/**
 * @param {String} result
 * @type void
 */
rd: function(result){},

/**
 * @param {String} result
 * @type void
 */
returnstatic: function(result){},

/**
 * @param {String} result
 * @type void
 */
rs: function(result){},

/**
 * @param {String} result
 * @type void
 */
returnquery: function(result){},

/**
 * @param {String} result
 * @param {String} alias
 * @type void
 */
returnquery: function(result, alias){},

/**
 * @param {Object} result
 * @type void
 */
returnobject: function(result){},

/**
 * @param {Object} result
 * @type void
 */
ro: function(result){},

/**
 * @param {String} result
 * @type void
 */
rq: function(result){},

/**
 * @param {String} result
 * @param {String} alias
 * @type void
 */
rq: function(result, alias){},

/**
 * @param {String} result
 * @type void
 */
returnstaticquery: function(result){},

/**
 * @param {String} result
 * @param {String} alias
 * @type void
 */
returnstaticquery: function(result, alias){},

/**
 * @param {String} result
 * @type void
 */
rsq: function(result){},

/**
 * @param {String} result
 * @param {String} alias
 * @type void
 */
rsq: function(result, alias){},

/**
 * @param {String} result
 * @param {String} value
 * @type void
 */
localvar: function(name, value){},

/**
 * @param {String} result
 * @param {String} value
 * @type void
 */
imagevar: function(name, value){},

/**
 * @param {String} result
 * @param {String} value
 * @type void
 */
globalvar: function(name, value){},

/**
 * @param {String} result
 * @param {String} value
 * @type void
 */
setvar: function(name, value){},

/**
 * @param {String} name
 * @type Object
 */
valueof: function(name){},

/**
 * @param {String} name
 * @type Object
 */
valueofObj: function(name){},

/**
 * @param {String} name
 * @type Boolean
 */
hasvar: function(name){},

/**
 * @param {String} fieldname
 * @param {String} value
 * @type void
 */
setValue: function(fieldname, value){},

/**
 * @param {Object} keyValues
 * @type void
 */
setValues: function(keyValues){},

/**
 * @param {String} value
 * @type Number
 */
strToDouble: function(value){},

/**
 * @param {String} value
 * @type Number
 */
strToLong: function(value){},

/**
 * @param {String} name
 * @param {String} condition
 * @param {Boolean} newWindow
 * @param {Number} frameMode
 * @type void
 */
openFrame: function(name, condition, newWindow, frameMode){},

/**
 * @param {String} name
 * @param {String} condition
 * @param {Boolean} newWindow
 * @param {Number} frameMode
 * @param {Array} windowDetails
 * @type void
 */
openFrame: function(name, condition, newWindow, frameMode, windowDetails){},

/**
 * @param {String} name
 * @param {String} condition
 * @param {Boolean} newWindow
 * @param {Number} frameMode
 * @param {Array} windowDetails
 * @param {Boolean} resetConditionAtSearch
 * @type void
 */
openFrame: function(name, condition, newWindow, frameMode, windowDetails, resetConditionAtSearch){},

/**
 * @param {String} name
 * @param {String} condition
 * @param {Boolean} newWindow
 * @param {Number} frameMode
 * @param {Array} windowDetails
 * @param {Boolean} resetConditionAtSearch
 * @param {Object} prompts
 * @type void
 */
openFrame: function(name, condition, newWindow, frameMode, windowDetails, resetConditionAtSearch, prompts){},

/**
 * @param {String} name
 * @param {String} condition
 * @param {Boolean} newWindow
 * @param {Number} frameMode
 * @param {String} links
 * @type void
 */
openLinkedFrame: function(name, condition, newWindow, frameMode, links){},

/**
 * @param {String} name
 * @param {String} condition
 * @param {Boolean} newWindow
 * @param {Number} frameMode
 * @param {String} links
 * @param {Array} windowDetails
 * @type void
 */
openLinkedFrame: function(name, condition, newWindow, frameMode, links, windowDetails){},

/**
 * @param {String} name
 * @param {String} condition
 * @param {Boolean} newWindow
 * @param {Number} frameMode
 * @param {String} links
 * @param {Array} windowDetails
 * @param {Boolean} resetConditionAtSearch
 * @type void
 */
openLinkedFrame: function(name, condition, newWindow, frameMode, links, windowDetails, resetConditionAtSearch){},

/**
 * @param {String} name
 * @param {String} condition
 * @param {Boolean} newWindow
 * @param {Number} frameMode
 * @param {String} links
 * @param {Array} windowDetails
 * @param {Boolean} resetConditionAtSearch
 * @param {Object} prompts
 * @type void
 */
openLinkedFrame: function(name, condition, newWindow, frameMode, links, windowDetails, resetConditionAtSearch, prompts){},

/**
 * @param {String} condition
 * @type void
 */
setImageCondition: function(condition){},

/**
 * @param {Number} type
 * @param {Array} details
 * @type void
 */
doClientCommand: function(type, details){},

/**
 * @param {Number} type
 * @param {Array} details
 * @type Object
 */
doClientIntermediate: function(type, details){},

/**
 * @param {String} encoded
 * @type Array
 */
decodeMS: function(encoded){},

/**
 * @param {String} encoded
 * @type String
 */
decodeFirst: function(encoded){},

/**
 * @param {Array} decoded
 * @type String
 */
encodeMS: function(decoded){},

/**
 * @param {String} input
 * @param {String} lineDelim
 * @param {String} fieldDelim
 * @param {String} fieldLimit
 * @type Array
 */
doubleSplit: function(input, lineDelim, fieldDelim, fieldLimit){},

/**
 * @param {Object} sql
 * @type String
 */
sql: function(sql){},

/**
 * @param {Object} sql
 * @param {String} alias
 * @type String
 */
sql: function(sql, alias){},

/**
 * @param {Object} sql
 * @param {Number} returnmode
 * @type Array
 */
sql: function(sql, returnmode){},

/**
 * @param {Object} sql
 * @param {String} alias
 * @param {Number} returnmode
 * @type Array
 */
sql: function(sql, alias, returnmode){},

/**
 * @param {Object} sql
 * @param {Object} returnmode
 * @type Array
 */
sql: function(sql, returnmode){},

/**
 * @param {Object} sql
 * @param {String} alias
 * @param {Object} returnmode
 * @type Array
 */
sql: function(sql, alias, returnmode){},

/**
 * @param {Object} sql
 * @param {Object} resultMode
 * @param {Number} maxRows
 * @type Array
 */
sql: function(sql, resultMode, maxRows){},

/**
 * @param {Object} sql
 * @param {String} alias
 * @param {Object} resultMode
 * @param {Number} maxRows
 * @type Array
 */
sql: function(sql, alias, resultMode, maxRows){},

/**
 * @param {Object} sql
 * @param {Number} resultMode
 * @param {Number} maxRows
 * @type Array
 */
sql: function(sql, resultMode, maxRows){},

/**
 * @param {Object} sql
 * @param {String} alias
 * @param {Number} resultMode
 * @param {Number} maxRows
 * @type Array
 */
sql: function(sql, alias, resultMode, maxRows){},

/**
 * @param {String} tableName
 * @param {Array} columns
 * @param {Array} columnTypes
 * @param {Array} values
 * @param {String} alias
 * @type Number
 */
getRowCount: function(tableName, columns, columnTypes, values, alias){},

/**
 * @param {String} tableName
 * @param {Array} columns
 * @param {Array} columnTypes
 * @param {Array} values
 * @type Number
 */
getRowCount: function(tableName, columns, columnTypes, values){},

/**
 * @param {String} tableName
 * @param {Array} columns
 * @param {Array} columnTypes
 * @param {Array} values
 * @type Number
 */
sqlInsert: function(tableName, columns, columnTypes, values){},

/**
 * @param {String} tableName
 * @param {Array} columns
 * @param {Array} columnTypes
 * @param {Array} values
 * @param {String} alias
 * @type Number
 */
sqlInsert: function(tableName, columns, columnTypes, values, alias){},

/**
 * @param {Array} statements
 * @type Number
 */
sqlInsert: function(statements){},

/**
 * @param {Array} statements
 * @param {String} alias
 * @type Number
 */
sqlInsert: function(statements, alias){},

/**
 * @param {String} tableName
 * @param {Array} columns
 * @param {Array} columnTypes
 * @param {Array} values
 * @param {String} condition
 * @type Number
 */
sqlUpdate: function(tableName, columns, columnTypes, values, condition){},

/**
 * @param {String} tableName
 * @param {Array} columns
 * @param {Array} columnTypes
 * @param {Array} values
 * @param {String} condition
 * @param {String} alias
 * @type Number
 */
sqlUpdate: function(tableName, columns, columnTypes, values, condition, alias){},

/**
 * @param {Array} statements
 * @type Number
 */
sqlUpdate: function(statements){},

/**
 * @param {Array} statements
 * @param {String} alias
 * @type Number
 */
sqlUpdate: function(statements, alias){},

/**
 * @param {Array} statements
 * @type Number
 */
sqlMix: function(statements){},

/**
 * @param {Array} statements
 * @param {String} alias
 * @type Number
 */
sqlMix: function(statements, alias){},

/**
 * @param {String} tableName
 * @param {String} condition
 * @type Number
 */
sqlDelete: function(tableName, condition){},

/**
 * @param {String} tableName
 * @param {String} condition
 * @param {String} alias
 * @type Number
 */
sqlDelete: function(tableName, condition, alias){},

/**
 * @param {Array} statements
 * @type Number
 */
sqlDelete: function(statements){},

/**
 * @param {Array} statements
 * @param {String} alias
 * @type Number
 */
sqlDelete: function(statements, alias){},

/**
 * @param {String} table
 * @param {String} idColumn
 * @type String
 */
getNewID: function(table, idColumn){},

/**
 * @param {String} table
 * @param {String} idColumn
 * @param {String} alias
 * @type String
 */
getNewID: function(table, idColumn, alias){},

/**
 * @param {String} name
 * @param {Boolean} newWindow
 * @param {String} condition
 * @param {Number} mode
 * @param {Array} modeDetails
 * @type void
 */
openReport: function(name, newWindow, condition, mode, modeDetails){},

/**
 * @param {String} name
 * @param {Boolean} newWindow
 * @param {String} condition
 * @param {Number} mode
 * @param {Array} modeDetails
 * @param {Object} prompts
 * @type void
 */
openReport: function(name, newWindow, condition, mode, modeDetails, prompts){},

/**
 * @param {String} name
 * @param {Number} windowMode
 * @param {String} condition
 * @param {Number} mode
 * @param {Array} modeDetails
 * @param {Object} prompts
 * @type void
 */
openReport: function(name, windowMode, condition, mode, modeDetails, prompts){},

/**
 * @param {String} name
 * @param {Boolean} newWindow
 * @param {Number} mode
 * @param {Array} modeDetails
 * @param {Array} columnNames
 * @param {Array} data
 * @type void
 */
openStaticReport: function(name, newWindow, mode, modeDetails, columnNames, data){},

/**
 * @param {String} name
 * @param {Number} windowMode
 * @param {Number} mode
 * @param {Array} modeDetails
 * @param {Array} columnNames
 * @param {Array} data
 * @type void
 */
openStaticReport: function(name, windowMode, mode, modeDetails, columnNames, data){},

/**
 * @param {String} name
 * @param {Boolean} newWindow
 * @param {Number} mode
 * @param {Array} modeDetails
 * @param {Object} prompts
 * @param {Array} columnNames
 * @param {Array} data
 * @type void
 */
openStaticReport: function(name, newWindow, mode, modeDetails, prompts, columnNames, data){},

/**
 * @param {String} name
 * @param {Number} windowMode
 * @param {Number} mode
 * @param {Array} modeDetails
 * @param {Object} prompts
 * @param {Array} columnNames
 * @param {Array} data
 * @type void
 */
openStaticReport: function(name, windowMode, mode, modeDetails, prompts, columnNames, data){},

/**
 * @param {String} name
 * @param {Number} windowMode
 * @param {Number} mode
 * @param {Array} modeDetails
 * @param {Object} prompts
 * @param {Array} columnNames
 * @param {Array} data
 * @type void
 */
openStaticLinkedReport: function(name, windowMode, mode, modeDetails, prompts, columnNames, data){},

/**
 * @param {String} name
 * @param {Boolean} newWindow
 * @param {Number} mode
 * @param {Array} modeDetails
 * @param {Object} prompts
 * @param {Array} columnNames
 * @param {Array} data
 * @type void
 */
openStaticLinkedReport: function(name, newWindow, mode, modeDetails, prompts, columnNames, data){},

/**
 * @param {String} name
 * @param {Boolean} newWindow
 * @param {String} condition
 * @param {Number} mode
 * @param {Array} modeDetails
 * @param {String} whereOrder
 * @type void
 */
openLinkedReport: function(name, newWindow, condition, mode, modeDetails, whereOrder){},

/**
 * @param {String} name
 * @param {Boolean} newWindow
 * @param {String} condition
 * @param {Number} mode
 * @param {Array} modeDetails
 * @param {String} whereOrder
 * @param {Object} prompts
 * @type void
 */
openLinkedReport: function(mame, newWindow, condition, mode, modeDetails, whereOrder, prompts){},

/**
 * @param {String} name
 * @param {Number} windowMode
 * @param {String} condition
 * @param {Number} mode
 * @param {Array} modeDetails
 * @param {String} whereOrder
 * @param {Object} prompts
 * @type void
 */
openLinkedReport: function(name, windowMode, condition, mode, modeDetails, whereOrder, prompts){},
/**
 * @param {String} name
 * @param {Boolean} newWindow
 * @param {String} condition
 * @param {Number} mode
 * @param {Array} modeDetails
 * @param {String} whereOrder
 * @param {Object} prompts
 * @param {Array} columnNames
 * @param {Array} data
 * @type void
 */
openLinkedReport: function(name, newWindow, condition, mode, modeDetails, whereOrder, prompts, columnNames, data){},

/**
 * @param {String} name
 * @param {int} windowMode
 * @param {String} condition
 * @param {Number} mode
 * @param {Array} modeDetails
 * @param {String} whereOrder
 * @param {Object} prompts
 * @param {Array} columnNames
 * @param {Array} data
 * @type void
 */
openLinkedReport: function(name, windowMode, condition, mode, modeDetails, whereOrder, prompts, columnNames, data){},

/**
 * @param {String} reportName
 * @param {String} condition
 * @param {Number} exportFormat
 * @param {String} whereOrder
 * @param {Object} prompts
 * @param {Array} columnNames
 * @param {Array} data
 * @type void
 */
exportReportToBytes: function(reportName, condition, exportFormat, whereOrder, prompts, columnNames, data){},

/**
 * @param {String} reportName
 * @param {String} condition
 * @param {Number} exportFormat
 * @param {String} exportFile
 * @param {String} whereOrder
 * @param {Object} prompts
 * @param {Array} columnNames
 * @param {Array} data
 * @param {Boolean} waitFor
 * @param {String} identifier
 * @type void
 */
exportReportToFile: function(reportName, condition, exportFormat, exportFile, whereOrder, prompts, columnNames, data, waitFor, identifier){},

/**
 * @param {String} dateAsLong
 * @type String
 */
longToDate: function(dateAsLong){},

/**
 * @param {String} dateAsLong
 * @param {String} pattern
 * @type String
 */
longToDate: function(dateAsLong, pattern){},

/**
 * @param {String} date
 * @type String
 */
dateToLong: function(date){},

/**
 * @param {String} dateAsLong
 * @param {String} pattern
 * @type String
 */
dateToLong: function(dateAsLong, pattern){},

/**
 * @param {String} text
 * @type void
 */
showMessage: function(text){},

/**
 * @param {String} text
 * @param {Number} messageTyp
 * @param {String} detail
 * @type void
 */
askQuestion: function(text, messageTyp, detail){},

/**
 * @param {String} text
 * @param {String} framename
 * @type Object
 */
askUserQuestion: function(text, framename){},

/**
 * @param {String} title
 * @param {String} file
 * @param {String} statement
 * @param {String} fieldDivider
 * @param {String} fieldLimiter
 * @param {String} sentenceDivider
 * @param {Boolean} withFieldIdentifier
 * @param {Number} handleOldFile
 * @param {String} alias
 * @param {Boolean} waitFor
 * @type Boolean
 */
exportData: function(title, file, statement, fieldDivider, fieldLimiter, sentenceDivider, withFieldIdentifier, handleOldFile, alias, waitFor){},

/**
 * @param {String} title
 * @param {String} file
 * @param {String} statement
 * @param {String} fieldDivider
 * @param {String} fieldLimiter
 * @param {String} sentenceDivider
 * @param {Boolean} withFieldIdentifier
 * @param {Number} handleOldFile
 * @param {String} alias
 * @param {Boolean} waitFor
 * @param {String} charset
 * @param {String} locale
 * @param {String} escapeSymbol
 * @param {Number} escapeStrategy
 * @param {Array} outputFormat
 * @type Boolean
 */
fastExportData: function(title, file, statement, fieldDivider, fieldLimiter, sentenceDivider, withFieldIdentifier, handleOldFile, alias, waitFor, charset, locale, escapeSymbol, escapeStrategy, outputFormat){},

/**
 * @param {String} name
 * @type Array
 */
getAliasModel: function(name){},

/**
 * @param {String} name
 * @param {Number} kind
 * @type String
 */
getAlias: function(name, kind){},

/**
 * @param {String} alias
 * @type Array
 */
getTables: function(alias){},

/**
 * @param {String} alias
 * @param {String} table
 * @type Array
 */
getColumns: function(alias, table){},

/**
 * @param {String} alias
 * @param {String} table
 * @param {Array} columnNames
 * @type Array
 */
getColumnTypes: function(alias, table, columnNames){},

/**
 * @param {String} table
 * @param {Array} columnNames
 * @type Array
 */
getColumnTypes: function(table, columnNames){},

/**
 * @param void
 * @type void
 */
closeCurrentTopImage: function(){},

/**
 * @param void
 * @type Boolean
 */
closeAllowed: function(){},

/**
 * @param {String} windowID
 * @param {String} imageID
 * @type Boolean
 */
closeAllowed: function(windowID, imageID){},

/**
 * @param void
 * @type String
 */
getCurrentImageContent: function(){},

/**
 * @param {String} windowID
 * @param {String} imageID
 * @type String
 */
getImageContent: function(windowID, imageID){},

/**
 * @param {String} windowID
 * @param {String} imageID
 * @type Boolean
 */
existsImage: function(windowID, imageID){},

/**
 * @param {String} windowID
 * @param {String} imageID
 * @type void
 */
closeTopImage: function(windowID, imageID){},

/**
 * @param {Number} selection
 * @type void
 */
doAction: function(selection){},

/**
 * @param {Number} selection
 * @param {String} windowID
 * @param {String} topImageID
 * @type void
 */
doAction: function(selection, windowID, topImageID){},

/**
 * @param {String} code
 * @type String
 */
resolveVariables: function(code){},

/**
 * @param {String} name
 * @type String
 */
executeProcess: function(name){},

/**
 * @param {String} name
 * @param {Object} localVariables
 * @type String
 */
executeProcess: function(name, localVariables){},

/**
 * @param void
 * @type Array
 */
getActiveTimers: function(){},

/**
 * @param {String} identifier
 * @param {String} name
 * @param {Number} interval
 * @param {Boolean} runImmediately
 * @param {Boolean} showErrorDialog
 * @param {Number} timerType
 * @type void
 */
executeProcessTimer: function(identifier, name, interval, runImmediately, showErrorDialog, timerType){},

/**
 * @param {String} identifier
 * @param {String} name
 * @param {Number} interval
 * @param {Boolean} runImmediately
 * @param {Boolean} showErrorDialog
 * @param {Number} timerType
 * @param {String} user
 * @type void
 */
executeProcessTimer: function(identifier, name, interval, runImmediately, showErrorDialog, timerType, user){},

/**
 * @param {String} identifier
 * @param {String} name
 * @param {Number} interval
 * @param {Boolean} runImmediately
 * @param {Boolean} showErrorDialog
 * @param {Number} timerType
 * @param {String} user
 * @param {Boolean} keepJDito
 * @type void
 */
executeProcessTimer: function(identifier, name, interval, runImmediately, showErrorDialog, timerType, user, keepJDito){},
/**
 * @param {String} identifier
 * @type Boolean
 */
existsProcessTimer: function(identifier){},

/**
 * @param {String} identifier
 * @type void
 */
stopProcessTimer: function(identifier){},

/**
 * @param {String} pLong
 * @param {String} pattern
 * @type String
 */
formatLong: function(pLong, pattern){},

/**
 * @param {String} formatted
 * @param {String} pattern
 * @type Number
 */
parseLong: function(formatted, pattern){},

/**
 * @param {String} pLong
 * @param {String} pattern
 * @type String
 */
formatDouble: function(pLong, pattern){},

/**
 * @param {String} formatted
 * @param {String} pattern
 * @type Number
 */
parseDouble: function(formatted, pattern){},

/**
 * @param {String} filename
 * @type String
 */
getMimeType: function(filename){},

/**
 * @param void
 * @type void
 */
refresh: function(){},

/**
 * @param {Number} columnCount
 * @type Object
 */
createEmptyTable: function(columnCount){},

/**
 * @param {String} group
 * @type Boolean
 */
checkGroup: function(group){},

/**
 * @param {String} alias
 * @type Number
 */
getDatabaseType: function(alias){},

/**
 * @param {Array} tableNames
 * @type void
 */
setTablesCanBeDeleted: function(tableNames){},

/**
 * @param {Array} tableNames
 * @type void
 */
setTablesCanBeCreated: function(tableNames){},

/**
 * @param {Array} tableNames
 * @type void
 */
setTablesCanBeEdited: function(tableNames){},

/**
 * @param void
 * @type String
 */
getCurrentAlias: function(){},

/**
 * @param void
 * @type Array
 */
getTopImages: function(){},

/**
 * @param {Number} kind
 * @type Array
 */
getDataModels: function(kind){},

/**
 * @param {Number} kind
 * @param {String} name
 * @type Array
 */
getDataModel: function(kind, name){},

/**
 * @param {Number} kind
 * @param {String} name
 * @type Array
 */
getDataModels: function(kind, name){},

/**
 * @param {Number} time
 * @type void
 */
sleep: function(time){},

/**
 * @param void
 * @type String
 */
getNewUUID: function(){},

/**
 * @param {String} HTML
 * @type String
 */
html2text: function(HTML){},

/**
 * @param {String} RTF
 * @type String
 */
rtf2text: function(RTF){},
/**
 * @param {Number} numBytes
 * @type String
 */
getRandom: function(numBytes){},

/**
 * @param {String} key
 * @type String
 */
translate: function(key){},

/**
 * @param {String} key
 * @param {String} locale
 * @type String
 */
translate: function(key, locale){},

/**
 * @param {String} key
 * @param {Boolean} safe
 * @type String
 */
translate: function(key, safe){},

/**
 * @param {String} key
 * @param {String} locale
 * @param {Boolean} safe
 * @type String
 */
translate: function(key, locale, safe){},

/**
 * @param {String} componentName
 * @type void
 */
refresh: function(componentName){},

/**
 * @param {String} componentName
 * @param {String} windowID
 * @param {String} imageID
 * @type void
 */
refresh: function(componentName, windowID, imageID){},

/**
 * @param {String} componentName
 * @param {String} key
 * @type void
 */
sendKey: function(componentName, key){},

/**
 * @param {String} componentName
 * @param {String} key
 * @param {String} windowID
 * @param {String} imageID
 * @type void
 */
sendKey: function(componentName, key, windowID, imageID){},

/**
 * @param {String} registerTabName
 * @type void
 */
showRegisterTab: function(registerTabName){},

/**
 * @param {String} registerTabName
 * @param {String} windowID
 * @param {String} imageID
 * @type void
 */
showRegisterTab: function(registerTabName, windowID, imageID){},

/**
 * @param {String} title
 * @param {String} message
 * @param {String} type
 * @type void
 */
systemTrayShow: function(title, message, type){},

/**
 * @param void
 * @type void
 */
systemTrayRestore: function(){},

/**
 * @param {String} input
 * @param {String} lineDelim
 * @param {String} fieldDelim
 * @param {String} fieldLimit
 * @type Array
 */
parseCSV: function(input, lineDelim, fieldDelim, fieldLimit){},

/**
 * @param {Array} elements
 * @param {String} lineDelim
 * @param {String} fieldDelim
 * @param {String} fieldLimit
 * @type String
 */
toCSV: function(elements, lineDelim, fieldDelim, fieldLimit){},

/**
 * @param {String} text
 * @type String
 */
encodeBase64String: function(text){},

/**
 * @param {String} text
 * @param {String} charset
 * @type String
 */
encodeBase64String: function(text, charset){},

/**
 * @param {String} text
 * @type String
 */
decodeBase64String: function(text){},

/**
 * @param {String} text
 * @param {String} charset
 * @type String
 */
decodeBase64String: function(text, charset){},

/**
 * @param {String} text
 * @param {Object} replacements
 * @type String
 */
replaceAll: function(text, replacements){},


//print: function(text){}, // nur f�r interne Zwecke // TODO

/**
 * @param {String} componentName
 * @type void
 */
setFocus: function(componentName){},

/**
 * @param {String} componentName
 * @param {String} windowID
 * @param {String} imageID
 * @type void
 */
setFocus: function(componentName, windowID, imageID){},

/**
 * @param {String} key
 * @type String
 */
getVMProperty: function(key){},

/**
 * @param {String} tableName
 * @param {Array} iDs
 * @type Array
 */
getTableData: function(tableName, iDs){},

/**
 * @param {String} windowID
 * @param {String} imageID
 * @param {String} tableName
 * @param {Array} iDs
 * @type Array
 */
getTableData: function(windowID, imageID, tableName, iDs){},

/**
 * @param {String} windowID
 * @param {String} imageID
 * @param {String} tableName
 * @param {Number} attribute
 * @type Array
 */
getTableData: function(windowID, imageID, tableName, attribute){},

/**
 * @param {String} tableName
 * @param {Number} attribute
 * @type Array
 */
getTableData: function(tableName, attribute){},

/**
 * @param {String} tableName
 * @type String
 */
addTableRow: function(tableName){},

/**
 * @param {String} windowID
 * @param {String} imageID
 * @param {String} tableName
 * @type String
 */
addTableRow: function(windowID, imageID, tableName){},

/**
 * @param {String} tableName
 * @param {Array} uIDs
 * @type void
 */
deleteTableRows: function(tableName, uIDs){},

/**
 * @param {String} windowID
 * @param {String} imageID
 * @param {String} tableName
 * @param {Array} uIDs
 * @type void
 */
deleteTableRows: function(windowID, imageID, tableName, uIDs){},

/**
 * @param {String} tableName
 * @param {Array} uIDs
 * @param {Number} column
 * @param {String} IDValue
 * @param {String} viewValue
 * @type void
 */
updateTableCell: function(tableName, uID, column, iDValue, viewValue){},

/**
 * @param {String} windowID
 * @param {String} imageID
 * @param {String} tableName
 * @param {Array} uIDs
 * @param {Number} column
 * @param {String} iDValue
 * @param {String} viewValue
 * @type void
 */
updateTableCell: function(windowID, imageID, tableName, uID, column, iDValue, viewValue){},

/**
 * @param {String} tableName
 * @param {Array} uIDs
 * @type void
 */
undoTableEdit: function(tableName, uIDs){},

/**
 * @param {String} windowID
 * @param {String} imageID
 * @param {String} tableName
 * @param {Array} uIDs
 * @type void
 */
undoTableEdit: function(windowID, imageID, tableName, uIDs){},

/**
 * @param {String} tableName
 * @type void
 */
saveTableEdit: function(tableName){},

/**
 * @param {String} windowID
 * @param {String} imageID
 * @param {String} tableName
 * @type void
 */
saveTableEdit: function(windowID, imageID, tableName){},

/**
 * @param {String} tableName
 * @param {Array} uIDs
 * @param {Boolean} reloadMissing
 * @type void
 */
setTableSelection: function(tableName, uIDs, reloadMissing){},

/**
 * @param {String} windowID
 * @param {String} imageID
 * @param {String} tableName
 * @param {Array} uIDs
 * @param {Boolean} reloadMissing
 * @type void
 */
setTableSelection: function(windowID, imageID, tableName, uIDs, reloadMissing){},

/**
 * @param {String} tableName
 * @param {Array} uIDs
 * @param {Boolean} reloadMissing
 * @param {Number} column
 * @param {Number} vAlignment
 * @type void
 */
setTableSelection: function(tableName, uIDs, reloadMissing, column, vAlignment){},

/**
 * @param {String} windowID
 * @param {String} imageID
 * @param {String} tableName
 * @param {Array} uIDs
 * @param {Boolean} reloadMissing
 * @param {Number} column
 * @param {Number} vAlignment
 * @type void
 */
setTableSelection: function(windowID, imageID, tableName, uIDs, reloadMissing, column, vAlignment){},

/**
 * @param {String} unzippedBytes
 * @type String
 */
zip: function(unzippedBytes){},

/**
 * @param {String} zippedBytes
 * @type String
 */
unzip: function(zippedBytes){},

/**
 * @param {String} text
 * @param {Array} keys
 * @type String
 */
translate: function(text, keys){},

/**
 * @param {String} text
 * @param {Array} keys
 * @param {String} locale
 * @type String
 */
translate: function(text, keys, locale){},

/**
 * @param {String} text
 * @param {Array} keys
 * @param {boolean} safe
 * @type String
 */
translate: function(text, keys, safe){},

/**
 * @param {String} text
 * @param {Array} keys
 * @param {String} locale
 * @param {boolean} safe
 * @type String
 */
translate: function(text, keys, locale, safe){},

/**
 * @param {String} tableName
 * @param {Array} keyWords
 * @param {Boolean} operator
 * @type void
 */
setTableSelectionByKeywords: function(tableName, keyWords, operator){},

/**
 * @param {String} windowID
 * @param {String} imageID
 * @param {String} tableName
 * @param {Array} keywords
 * @param {Boolean} operator
 * @type void
 */
setTableSelectionByKeywords: function(windowID, imageID, tableName, keywords, operator){},

/**
 * @param {String} tableName
 * @param {Array} keywords
 * @param {Boolean} operator
 * @param {Number} column
 * @param {Number} vAlignment
 * @type void
 */
setTableSelectionByKeywords: function(tableName, keyWords, operator, column, vAlignment){},

/**
 * @param {String} windowID
 * @param {String} imageID
 * @param {String} tableName
 * @param {Array} keywords
 * @param {Boolean} operator
 * @param {Number} column
 * @param {Number} vAlignment
 * @type void
 */
setTableSelectionByKeywords: function(windowID, imageID, tableName, keywords, operator, column, vAlignment){},

/**
 * @param {String} tableName
 * @param {Number} rowRelative
 * @param {Number} colRelative
 * @param {Number} vAlignment
 * @type void
 */
setTableSelectionRelative: function(tableName, rowRelative, colRelative, vAlignment){},

/**
 * @param {String} windowID
 * @param {String} imageID
 * @param {String} tableName
 * @param {Number} rowRelative
 * @param {Number} colRelative
 * @param {Number} vAlignment
 * @type void
 */
setTableSelectionRelative: function(windowID, imageID, tableName, rowRelative, colRelative, vAlignment){},

/**
 * @param {String} tableName
 * @param {Number} columnIndex
 * @param {Boolean} visibility
 * @type void
 */
setTableColumnVisibility: function(tableName, columnIndex, visibility){},

/**
 * @param {String} windowID
 * @param {String} imageID
 * @param {String} tableName
 * @param {Number} columnIndex
 * @param {Boolean} visibility
 * @type void
 */
setTableColumnVisibility: function(windowID, imageID, tableName, columnIndex, visibility){},

/**
 * @param void
 * @type Array
 */
getCurrentRowData: function(){},

/**
 * @param {String} windowID
 * @param {String} imageID
 * @type Array
 */
getCurrentRowData: function(windowID, imageID){}


};